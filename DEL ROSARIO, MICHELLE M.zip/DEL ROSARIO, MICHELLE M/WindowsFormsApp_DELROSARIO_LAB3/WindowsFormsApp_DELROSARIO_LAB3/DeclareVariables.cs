﻿
namespace WindowsFormsApp_DELROSARIO_LAB3
{
    class DeclareVariables
    {
        //Calculator Form
        public static double total1 = 0;
        public static double total2 = 0;
        public static bool plusButtonClicked = false;
        public static bool minusButtonClicked = false;
        public static bool multiplyButtonClicked = false;
        public static bool divideButtonClicked = false;
        // bool equalsButtonClicked = false;

        //Form3
        public static double t;
        public static bool IntegerButtonClicked = false;
        public static bool DoubleButtonClicked = false;
        public static bool FloatButtonClicked = false;


    }
}
