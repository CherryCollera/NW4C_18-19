﻿
namespace WindowsFormsApp_DELROSARIO_LAB3
{
    public partial class Form3 : System.Windows.Forms.Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, System.EventArgs e)
        {

        }

        private void btnComputeSum_Click(object sender, System.EventArgs e)
        {
            if (tb1.Text == "" && tb2.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Fill values in the field!");
            }
            else
            {
                if (DeclareVariables.IntegerButtonClicked == true)
                {
                    try
                    {
                        DeclareVariables.t = System.Convert.ToInt32(tb1.Text) + System.Convert.ToInt32(tb2.Text);
                        tb1.Clear();
                        tb2.Clear();
                        System.Windows.Forms.MessageBox.Show("Sum is: " + DeclareVariables.t);
                    }
                    catch (System.FormatException)
                    {
                        tb1.Clear();
                        tb2.Clear();
                        System.Windows.Forms.MessageBox.Show("Error. Value was not in a correct format!");
                    }
                }
                else if (DeclareVariables.DoubleButtonClicked == true)
                {
                    try
                    {
                        DeclareVariables.t = System.Convert.ToDouble(tb1.Text) + System.Convert.ToDouble(tb2.Text);
                        tb1.Clear();
                        tb2.Clear();
                        System.Windows.Forms.MessageBox.Show("Sum is: " + DeclareVariables.t);
                    }
                    catch (System.FormatException)
                    {
                        tb1.Clear();
                        tb2.Clear();
                        System.Windows.Forms.MessageBox.Show("Error. Value was not in a correct format!");
                    }
                }
                else if (DeclareVariables.FloatButtonClicked == true)
                {
                    try
                    {
                        DeclareVariables.t = float.Parse(tb1.Text) + float.Parse(tb2.Text);
                        tb1.Clear();
                        tb2.Clear();
                        System.Windows.Forms.MessageBox.Show("Sum is: " + DeclareVariables.t);
                    }
                    catch (System.FormatException)
                    {
                        tb1.Clear();
                        tb2.Clear();
                        System.Windows.Forms.MessageBox.Show("Error. Value was not in a correct format!");
                    }
                }
            }
        }


        private void btnInt_Click(object sender, System.EventArgs e)
        {
            DeclareVariables.IntegerButtonClicked = true;
            DeclareVariables.FloatButtonClicked = false;
            DeclareVariables.DoubleButtonClicked = false;
        }
        private void btnDouble_Click(object sender, System.EventArgs e)
        {
            DeclareVariables.IntegerButtonClicked = false;
            DeclareVariables.FloatButtonClicked = false;
            DeclareVariables.DoubleButtonClicked = true;

        }

        private void btnNext_Click(object sender, System.EventArgs e)
        {
            Form4 f4 = new Form4();
            this.Hide();
            f4.Show();
        }

        private void btnClose_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Close();
        }

        private void button3_Click(object sender, System.EventArgs e)
        {
            DeclareVariables.IntegerButtonClicked = false;
            DeclareVariables.FloatButtonClicked = true;
            DeclareVariables.DoubleButtonClicked = false;
        }
    }
}
