﻿
namespace WindowsFormsApp_DELROSARIO_LAB3
{
    public partial class Calculator : System.Windows.Forms.Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, System.EventArgs e)
        {
            TextBoxDisplay.Text = TextBoxDisplay.Text + btn1.Text;
        }

        private void btn2_Click(object sender, System.EventArgs e)
        {
            TextBoxDisplay.Text = TextBoxDisplay.Text + btn2.Text;
        }

        private void btn3_Click(object sender, System.EventArgs e)
        {
            TextBoxDisplay.Text = TextBoxDisplay.Text + btn3.Text;
        }

        private void btn4_Click(object sender, System.EventArgs e)
        {
            TextBoxDisplay.Text = TextBoxDisplay.Text + btn4.Text;
        }

        private void btn5_Click(object sender, System.EventArgs e)
        {
            TextBoxDisplay.Text = TextBoxDisplay.Text + btn5.Text;
        }

        private void btn6_Click(object sender, System.EventArgs e)
        {
            TextBoxDisplay.Text = TextBoxDisplay.Text + btn6.Text;
        }

        private void btn7_Click(object sender, System.EventArgs e)
        {
            TextBoxDisplay.Text = TextBoxDisplay.Text + btn7.Text;
        }

        private void btn8_Click(object sender, System.EventArgs e)
        {
            TextBoxDisplay.Text = TextBoxDisplay.Text + btn8.Text;
        }

        private void btn9_Click(object sender, System.EventArgs e)
        {
            TextBoxDisplay.Text = TextBoxDisplay.Text + btn9.Text;
        }

        private void btnpoint_Click(object sender, System.EventArgs e)
        {
            TextBoxDisplay.Text = TextBoxDisplay.Text + btnpoint.Text;
        }

        private void btn0_Click(object sender, System.EventArgs e)
        {
            TextBoxDisplay.Text = TextBoxDisplay.Text + btn0.Text;
        }

        private void btnClear_Click(object sender, System.EventArgs e)
        {
            TextBoxDisplay.Clear();
        }

        private void btnAdd_Click(object sender, System.EventArgs e)
        {
            DeclareVariables.total1 = DeclareVariables.total1 + double.Parse(TextBoxDisplay.Text);
            TextBoxDisplay.Clear();

            DeclareVariables.plusButtonClicked = true;
            DeclareVariables.minusButtonClicked = false;
            DeclareVariables.multiplyButtonClicked = false;
            DeclareVariables.divideButtonClicked = false;
        }

        private void btnDiff_Click(object sender, System.EventArgs e)
        {
            DeclareVariables.total1 = DeclareVariables.total1 + double.Parse(TextBoxDisplay.Text);
            TextBoxDisplay.Clear();

            DeclareVariables.plusButtonClicked = false;
            DeclareVariables.minusButtonClicked = true;
            DeclareVariables.multiplyButtonClicked = false;
            DeclareVariables.divideButtonClicked = false;
        }

        private void btnProd_Click(object sender, System.EventArgs e)
        {
            DeclareVariables.total1 = DeclareVariables.total1 + double.Parse(TextBoxDisplay.Text);
            TextBoxDisplay.Clear();

            DeclareVariables.plusButtonClicked = false;
            DeclareVariables.minusButtonClicked = false;
            DeclareVariables.multiplyButtonClicked = true;
            DeclareVariables.divideButtonClicked = false;
        }

        private void btnDiv_Click(object sender, System.EventArgs e)
        {
            DeclareVariables.total1 = DeclareVariables.total1 + double.Parse(TextBoxDisplay.Text);
            TextBoxDisplay.Clear();

            DeclareVariables.plusButtonClicked = false;
            DeclareVariables.minusButtonClicked = false;
            DeclareVariables.multiplyButtonClicked = false;
            DeclareVariables.divideButtonClicked = true;
        }

        private void btnEquals_Click(object sender, System.EventArgs e)
        {
            if(DeclareVariables.plusButtonClicked == true)
            {
                DeclareVariables.total2 = DeclareVariables.total1 + double.Parse(TextBoxDisplay.Text);
            }
            else if (DeclareVariables.minusButtonClicked == true)
            {
                DeclareVariables.total2 = DeclareVariables.total1 - double.Parse(TextBoxDisplay.Text);
            }
            else if (DeclareVariables.multiplyButtonClicked == true)
            {
                DeclareVariables.total2 = DeclareVariables.total1 * double.Parse(TextBoxDisplay.Text);
            }
            else if (DeclareVariables.divideButtonClicked == true)
            {
                DeclareVariables.total2 = DeclareVariables.total1 / double.Parse(TextBoxDisplay.Text);
            }

            TextBoxDisplay.Text = DeclareVariables.total2.ToString();
            DeclareVariables.total1 = 0;
        }

        private void btnExit_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Close();
        }
    }
}
