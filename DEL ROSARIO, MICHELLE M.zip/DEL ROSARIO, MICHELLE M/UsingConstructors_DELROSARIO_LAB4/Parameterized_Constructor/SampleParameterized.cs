﻿
namespace Parameterized_Constructor
{
    class SampleParameterized
    {
        public string fname, lname;
        public SampleParameterized(string a, string b) {
            fname = a;
            lname = b;
        }
    }
}
