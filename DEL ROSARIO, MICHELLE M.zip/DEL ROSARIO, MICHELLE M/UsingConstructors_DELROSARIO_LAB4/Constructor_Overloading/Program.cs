﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_Overloading
{
    class Program
    {
        static void Main(string[] args)
        {
            ConstructorOverloading c_overloading = new ConstructorOverloading();
            ConstructorOverloading c_over1 = new ConstructorOverloading("MICHELLE", "DEL ROSARIO");
            Console.WriteLine(c_overloading.fname + " " + c_overloading.lname);
            Console.WriteLine(c_over1.fname + " " + c_over1.lname);
            Console.ReadLine();

        }
    }
}
