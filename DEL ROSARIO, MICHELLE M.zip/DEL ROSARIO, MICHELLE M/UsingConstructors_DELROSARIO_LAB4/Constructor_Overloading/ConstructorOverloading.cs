﻿
namespace Constructor_Overloading
{
    class ConstructorOverloading
    {
        public string fname, lname;
        public ConstructorOverloading() {
            fname = "MICHELLE";
            lname = "DEL ROSARIO";
        }
        public ConstructorOverloading(string a, string b) {
            fname = a;
            lname = b;

        }
    }
}
