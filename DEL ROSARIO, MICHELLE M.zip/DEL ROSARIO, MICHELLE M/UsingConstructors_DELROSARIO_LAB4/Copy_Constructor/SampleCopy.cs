﻿
namespace Copy_Constructor
{
    class SampleCopy
    {
        public string fname, lname;
        public SampleCopy(string a, string b) {
            fname = a;
            lname = b;
        }
        public SampleCopy(SampleCopy samplecopy) {
            fname = samplecopy.fname;
            lname = samplecopy.lname;
        }
    }
}
