﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Copy_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            SampleCopy samplecopy = new SampleCopy("MICHELLE", "DEL ROSARIO");
            SampleCopy sample1 = new SampleCopy(samplecopy);
            Console.WriteLine(samplecopy);
            Console.WriteLine("\n" + sample1.fname + "\n\n" + sample1.lname);
            Console.ReadKey();
        }
    }
}
