﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation
{
    class Constructor
    {
        public Constructor() {
            DeclareVariables dv = new DeclareVariables();
            DeclareVariables.sum = DeclareVariables.a + DeclareVariables.b;
            Console.ReadLine();
        }
    }
}
