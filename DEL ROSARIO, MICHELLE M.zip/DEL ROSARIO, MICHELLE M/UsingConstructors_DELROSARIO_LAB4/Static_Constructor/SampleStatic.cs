﻿
namespace Static_Constructor
{
    class SampleStatic
    {
        public string fname, lname;

        static SampleStatic() {
            System.Console.WriteLine("Static Constructor");
        }
        public SampleStatic() {
            fname = "MICHELLE";
            lname = "DEL ROSARIO";
        }
    }
}
