﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Static_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            SampleStatic samplestatic = new SampleStatic();
            SampleStatic sample1 = new SampleStatic();
            Console.WriteLine(sample1.fname + " " + sample1.lname);
            Console.ReadKey();
        }
    }
}
