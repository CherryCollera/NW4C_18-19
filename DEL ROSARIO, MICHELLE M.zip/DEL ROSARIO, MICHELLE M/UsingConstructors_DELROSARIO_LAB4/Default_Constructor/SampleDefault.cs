﻿
namespace Default_Constructor
{
    class SampleDefault
    {
        public string fname, lname;
        public SampleDefault() {
            fname = "MICHELLE";
            lname = "DEL ROSARIO";
        }
    }
}
