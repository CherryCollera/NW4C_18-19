﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Default_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            SampleDefault sampledefault = new SampleDefault();
            Console.WriteLine(sampledefault.fname);
            Console.WriteLine(sampledefault.lname);
            Console.ReadLine();
        }
    }
}
