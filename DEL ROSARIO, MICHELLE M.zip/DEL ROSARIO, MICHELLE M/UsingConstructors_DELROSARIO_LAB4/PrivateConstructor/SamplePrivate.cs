﻿
namespace PrivateConstructor
{
    class SamplePrivate
    {
        public string fname, lname;
        public SamplePrivate(string a, string b) {
            fname = a;
            lname = b;
        }
        private SamplePrivate() {
            System.Console.WriteLine("Private Constructors with no Parameters.");
        }
    }
}
