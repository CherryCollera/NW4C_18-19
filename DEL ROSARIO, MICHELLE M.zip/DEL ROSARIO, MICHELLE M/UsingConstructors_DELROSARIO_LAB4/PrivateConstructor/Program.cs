﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateConstructor
{
    class Program
    {
        static void Main(string[] args)
        {
            SamplePrivate sampleprivate = new SamplePrivate("MICHELLE", "DEL ROSARIO");
            Console.WriteLine(sampleprivate.fname + " " + sampleprivate.lname);
            Console.ReadLine();

        }
    }
}
