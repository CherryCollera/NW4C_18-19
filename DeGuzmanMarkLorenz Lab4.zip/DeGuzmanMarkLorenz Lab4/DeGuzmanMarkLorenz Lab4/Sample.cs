﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeGuzmanMarkLorenz_Lab4
{
    class Sample
    {

        public string firstname, lastname;
        public Sample()
        {
            firstname = "Mark Lorenz ";
            lastname = "De Guzman";

        }
    }
}
