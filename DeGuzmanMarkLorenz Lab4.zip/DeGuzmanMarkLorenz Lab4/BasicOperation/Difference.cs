﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation
{
    class Product
    {

        public Product()
        {
            Declarevar var = new Declarevar();
            Console.WriteLine(var);
            Declarevar.Difference = Declarevar.num1 - Declarevar.num2;
            Console.ReadLine();
        }
    }
}
