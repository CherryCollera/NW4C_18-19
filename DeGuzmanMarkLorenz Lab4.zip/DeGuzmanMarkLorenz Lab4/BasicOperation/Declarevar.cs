﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation
{
    class Declarevar
    {
        public static int num1, num2, Difference;

        public Declarevar()
        {
            try
            {

                Console.Write("Enter First Number:\t");
                num1 = Convert.ToInt16(Console.ReadLine());
                Console.Write("Enter Second Number:\t");
                num2 = Convert.ToInt16(Console.ReadLine());
            }
            catch (FormatException e)
            {
                Console.WriteLine("Error:" + e.Message);
                throw;


            }

        }

    }
}