﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BONGCO_CALCULATOR
{
    class Declarevar
    {
        public static double total1 = 0;
        public static double total2 = 0;
        public static bool minusButtonClicked = false;
        public static bool plusButtonClicked = false;
        public static bool divideButtonClicked = false;
        public static bool multiplyButtonClicked = false;

        //public static bool equalsButtonClicked = false;
        public static double total;
        public static bool IntButtonClicked = false;
        public static bool DoubleButtonClicked = false;
        public static bool FloatButtonClicked = false;
    }
}
