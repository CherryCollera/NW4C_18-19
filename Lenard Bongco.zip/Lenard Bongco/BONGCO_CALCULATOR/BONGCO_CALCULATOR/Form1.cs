﻿
namespace BONGCO_CALCULATOR
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Calculator form = new Calculator();
            form.Show();
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show("Hello I'm Lenard M. Bongco!", "Message");
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form3 form = new Form3();
            form.Show();
        }

        private void button4_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
