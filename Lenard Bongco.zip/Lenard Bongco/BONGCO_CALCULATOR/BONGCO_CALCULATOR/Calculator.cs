﻿

namespace BONGCO_CALCULATOR
{
    public partial class Calculator : System.Windows.Forms.Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, System.EventArgs e)
        {

        }

        private void bttn4_Click(object sender, System.EventArgs e)
        {
            Declarevar.total1 = Declarevar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            Declarevar.minusButtonClicked = false;
            Declarevar.plusButtonClicked = true;
            Declarevar.divideButtonClicked = false;
            Declarevar.multiplyButtonClicked = false;
    }

        private void bttn8_Click(object sender, System.EventArgs e)
        {
            Declarevar.total1 = Declarevar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            Declarevar.minusButtonClicked = true;
            Declarevar.plusButtonClicked = false;
            Declarevar.divideButtonClicked = false;
            Declarevar.multiplyButtonClicked = false;
        }

        private void bttn12_Click(object sender, System.EventArgs e)
        {
            Declarevar.total1 = Declarevar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            Declarevar.minusButtonClicked = false;
            Declarevar.plusButtonClicked = false;
            Declarevar.divideButtonClicked = false;
            Declarevar.multiplyButtonClicked = true;
        }

        private void bttn16_Click(object sender, System.EventArgs e)
        {
            Declarevar.total1 = Declarevar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            Declarevar.minusButtonClicked = false;
            Declarevar.plusButtonClicked = false;
            Declarevar.divideButtonClicked = true;
            Declarevar.multiplyButtonClicked = false;
        }

        private void bttn14_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + bttn14.Text;
        }

        private void bttn1_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + bttn1.Text;
        }

        private void bttn18_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void bttn15_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Clear();
        }

        private void bttn17_Click(object sender, System.EventArgs e)
        {
            if (Declarevar.plusButtonClicked == true)
            {
                Declarevar.total2 = Declarevar.total1 + double.Parse(txtDisplay.Text);
            }

            else if (Declarevar.minusButtonClicked == true)
            {
                Declarevar.total2 = Declarevar.total1 - double.Parse(txtDisplay.Text);
            }

            else if (Declarevar.divideButtonClicked == true)
            {
                Declarevar.total2 = Declarevar.total1 / double.Parse(txtDisplay.Text);
            }

            else if (Declarevar.multiplyButtonClicked == true)
            {
                Declarevar.total2 = Declarevar.total1 * double.Parse(txtDisplay.Text);
            }

            txtDisplay.Text = Declarevar.total2.ToString();
            Declarevar.total1 = 0;
         
        }

        private void bttn2_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + bttn2.Text;
        }

        private void bttn3_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + bttn3.Text;
        }

        private void bttn5_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + bttn5.Text;
        }

        private void bttn6_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + bttn6.Text;
        }

        private void bttn7_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + bttn7.Text;
        }

        private void bttn9_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + bttn9.Text;
        }

        private void bttn10_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + bttn10.Text;
        }

        private void bttn11_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + bttn11.Text;
        }

        private void bttn13_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + bttn13.Text;
        }

        private void Calculator_Load(object sender, System.EventArgs e)
        {

        }
    }
}
