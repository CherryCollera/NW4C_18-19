﻿

namespace BONGCO_CALCULATOR
{
    public partial class Form3 : System.Windows.Forms.Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, System.EventArgs e)
        {

        }

        private void button6_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, System.EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Please Input Some Value in the TextBox", "Critical Warning");
            }
            else
            {
                if (Declarevar.IntButtonClicked == true)
                {
                    try
                    {
                        Declarevar.total = System.Convert.ToInt32(textBox1.Text) + System.Convert.ToInt32(textBox2.Text);
                        textBox1.Clear();
                        textBox2.Clear();
                        System.Windows.Forms.MessageBox.Show("The answer is: " + Declarevar.total);
                    }
                    catch (System.FormatException)
                    {
                        textBox1.Clear();
                        textBox2.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!", "Critical Warning");
                    }
                }
                else if (Declarevar.DoubleButtonClicked == true)
                {
                    try
                    {
                        Declarevar.total = System.Convert.ToDouble(textBox1.Text) + System.Convert.ToDouble(textBox2.Text);
                        textBox1.Clear();
                        textBox2.Clear();
                        System.Windows.Forms.MessageBox.Show("The answer is: " + Declarevar.total);
                    }
                    catch (System.FormatException)
                    {
                        textBox1.Clear();
                        textBox2.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!", "Critical Warning");
                    }
                }
                else if (Declarevar.FloatButtonClicked == true)
                {
                    try
                    {
                        Declarevar.total = float.Parse(textBox1.Text, System.Globalization.CultureInfo.InvariantCulture.NumberFormat) + float.Parse(textBox2.Text, System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                        textBox1.Clear();
                        textBox2.Clear();
                        System.Windows.Forms.MessageBox.Show("The answer is: " + Declarevar.total);
                    }
                    catch (System.FormatException)
                    {
                        textBox1.Clear();
                        textBox2.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!", "Critical Warning");
                    }
                }
            }
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            Declarevar.IntButtonClicked = true;
            Declarevar.DoubleButtonClicked = false;
            Declarevar.FloatButtonClicked = false;
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            Declarevar.IntButtonClicked = false;
            Declarevar.DoubleButtonClicked = true;
            Declarevar.FloatButtonClicked = false;
        }

        private void button3_Click(object sender, System.EventArgs e)
        {
            Declarevar.IntButtonClicked = false;
            Declarevar.DoubleButtonClicked = false;
            Declarevar.FloatButtonClicked = true;
        }

        private void button5_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form4 form4 = new Form4();
            form4.Show();
        }

        private void button7_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }
    }
}
