﻿namespace BONGCO_CALCULATOR
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDisplay = new System.Windows.Forms.TextBox();
            this.bttn1 = new System.Windows.Forms.Button();
            this.bttn2 = new System.Windows.Forms.Button();
            this.bttn3 = new System.Windows.Forms.Button();
            this.bttn4 = new System.Windows.Forms.Button();
            this.bttn5 = new System.Windows.Forms.Button();
            this.bttn6 = new System.Windows.Forms.Button();
            this.bttn7 = new System.Windows.Forms.Button();
            this.bttn8 = new System.Windows.Forms.Button();
            this.bttn9 = new System.Windows.Forms.Button();
            this.bttn10 = new System.Windows.Forms.Button();
            this.bttn11 = new System.Windows.Forms.Button();
            this.bttn12 = new System.Windows.Forms.Button();
            this.bttn13 = new System.Windows.Forms.Button();
            this.bttn15 = new System.Windows.Forms.Button();
            this.bttn16 = new System.Windows.Forms.Button();
            this.bttn17 = new System.Windows.Forms.Button();
            this.bttn18 = new System.Windows.Forms.Button();
            this.bttn14 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "CALCULATOR";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Compute Here!";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtDisplay
            // 
            this.txtDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDisplay.Location = new System.Drawing.Point(18, 56);
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.Size = new System.Drawing.Size(219, 26);
            this.txtDisplay.TabIndex = 2;
            // 
            // bttn1
            // 
            this.bttn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn1.Location = new System.Drawing.Point(18, 88);
            this.bttn1.Name = "bttn1";
            this.bttn1.Size = new System.Drawing.Size(50, 42);
            this.bttn1.TabIndex = 3;
            this.bttn1.Text = "1";
            this.bttn1.UseVisualStyleBackColor = true;
            this.bttn1.Click += new System.EventHandler(this.bttn1_Click);
            // 
            // bttn2
            // 
            this.bttn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn2.Location = new System.Drawing.Point(75, 88);
            this.bttn2.Name = "bttn2";
            this.bttn2.Size = new System.Drawing.Size(50, 42);
            this.bttn2.TabIndex = 4;
            this.bttn2.Text = "2";
            this.bttn2.UseVisualStyleBackColor = true;
            this.bttn2.Click += new System.EventHandler(this.bttn2_Click);
            // 
            // bttn3
            // 
            this.bttn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn3.Location = new System.Drawing.Point(131, 88);
            this.bttn3.Name = "bttn3";
            this.bttn3.Size = new System.Drawing.Size(50, 42);
            this.bttn3.TabIndex = 5;
            this.bttn3.Text = "3";
            this.bttn3.UseVisualStyleBackColor = true;
            this.bttn3.Click += new System.EventHandler(this.bttn3_Click);
            // 
            // bttn4
            // 
            this.bttn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn4.Location = new System.Drawing.Point(187, 88);
            this.bttn4.Name = "bttn4";
            this.bttn4.Size = new System.Drawing.Size(50, 42);
            this.bttn4.TabIndex = 6;
            this.bttn4.Text = "+";
            this.bttn4.UseVisualStyleBackColor = true;
            this.bttn4.Click += new System.EventHandler(this.bttn4_Click);
            // 
            // bttn5
            // 
            this.bttn5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn5.Location = new System.Drawing.Point(18, 136);
            this.bttn5.Name = "bttn5";
            this.bttn5.Size = new System.Drawing.Size(50, 42);
            this.bttn5.TabIndex = 7;
            this.bttn5.Text = "4";
            this.bttn5.UseVisualStyleBackColor = true;
            this.bttn5.Click += new System.EventHandler(this.bttn5_Click);
            // 
            // bttn6
            // 
            this.bttn6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn6.Location = new System.Drawing.Point(74, 136);
            this.bttn6.Name = "bttn6";
            this.bttn6.Size = new System.Drawing.Size(50, 42);
            this.bttn6.TabIndex = 8;
            this.bttn6.Text = "5";
            this.bttn6.UseVisualStyleBackColor = true;
            this.bttn6.Click += new System.EventHandler(this.bttn6_Click);
            // 
            // bttn7
            // 
            this.bttn7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn7.Location = new System.Drawing.Point(130, 136);
            this.bttn7.Name = "bttn7";
            this.bttn7.Size = new System.Drawing.Size(50, 42);
            this.bttn7.TabIndex = 9;
            this.bttn7.Text = "6";
            this.bttn7.UseVisualStyleBackColor = true;
            this.bttn7.Click += new System.EventHandler(this.bttn7_Click);
            // 
            // bttn8
            // 
            this.bttn8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn8.Location = new System.Drawing.Point(187, 136);
            this.bttn8.Name = "bttn8";
            this.bttn8.Size = new System.Drawing.Size(50, 42);
            this.bttn8.TabIndex = 10;
            this.bttn8.Text = "-";
            this.bttn8.UseVisualStyleBackColor = true;
            this.bttn8.Click += new System.EventHandler(this.bttn8_Click);
            // 
            // bttn9
            // 
            this.bttn9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn9.Location = new System.Drawing.Point(18, 184);
            this.bttn9.Name = "bttn9";
            this.bttn9.Size = new System.Drawing.Size(50, 42);
            this.bttn9.TabIndex = 11;
            this.bttn9.Text = "7";
            this.bttn9.UseVisualStyleBackColor = true;
            this.bttn9.Click += new System.EventHandler(this.bttn9_Click);
            // 
            // bttn10
            // 
            this.bttn10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn10.Location = new System.Drawing.Point(75, 184);
            this.bttn10.Name = "bttn10";
            this.bttn10.Size = new System.Drawing.Size(50, 42);
            this.bttn10.TabIndex = 12;
            this.bttn10.Text = "8";
            this.bttn10.UseVisualStyleBackColor = true;
            this.bttn10.Click += new System.EventHandler(this.bttn10_Click);
            // 
            // bttn11
            // 
            this.bttn11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn11.Location = new System.Drawing.Point(131, 184);
            this.bttn11.Name = "bttn11";
            this.bttn11.Size = new System.Drawing.Size(50, 42);
            this.bttn11.TabIndex = 13;
            this.bttn11.Text = "9";
            this.bttn11.UseVisualStyleBackColor = true;
            this.bttn11.Click += new System.EventHandler(this.bttn11_Click);
            // 
            // bttn12
            // 
            this.bttn12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn12.Location = new System.Drawing.Point(187, 184);
            this.bttn12.Name = "bttn12";
            this.bttn12.Size = new System.Drawing.Size(50, 42);
            this.bttn12.TabIndex = 14;
            this.bttn12.Text = "*";
            this.bttn12.UseVisualStyleBackColor = true;
            this.bttn12.Click += new System.EventHandler(this.bttn12_Click);
            // 
            // bttn13
            // 
            this.bttn13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn13.Location = new System.Drawing.Point(18, 232);
            this.bttn13.Name = "bttn13";
            this.bttn13.Size = new System.Drawing.Size(50, 42);
            this.bttn13.TabIndex = 15;
            this.bttn13.Text = "0";
            this.bttn13.UseVisualStyleBackColor = true;
            this.bttn13.Click += new System.EventHandler(this.bttn13_Click);
            // 
            // bttn15
            // 
            this.bttn15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn15.Location = new System.Drawing.Point(131, 232);
            this.bttn15.Name = "bttn15";
            this.bttn15.Size = new System.Drawing.Size(50, 42);
            this.bttn15.TabIndex = 17;
            this.bttn15.Text = "Clear";
            this.bttn15.UseVisualStyleBackColor = true;
            this.bttn15.Click += new System.EventHandler(this.bttn15_Click);
            // 
            // bttn16
            // 
            this.bttn16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn16.Location = new System.Drawing.Point(187, 232);
            this.bttn16.Name = "bttn16";
            this.bttn16.Size = new System.Drawing.Size(50, 42);
            this.bttn16.TabIndex = 18;
            this.bttn16.Text = "/";
            this.bttn16.UseVisualStyleBackColor = true;
            this.bttn16.Click += new System.EventHandler(this.bttn16_Click);
            // 
            // bttn17
            // 
            this.bttn17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn17.Location = new System.Drawing.Point(18, 278);
            this.bttn17.Name = "bttn17";
            this.bttn17.Size = new System.Drawing.Size(219, 42);
            this.bttn17.TabIndex = 19;
            this.bttn17.Text = "=";
            this.bttn17.UseVisualStyleBackColor = true;
            this.bttn17.Click += new System.EventHandler(this.bttn17_Click);
            // 
            // bttn18
            // 
            this.bttn18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn18.Location = new System.Drawing.Point(18, 326);
            this.bttn18.Name = "bttn18";
            this.bttn18.Size = new System.Drawing.Size(219, 42);
            this.bttn18.TabIndex = 20;
            this.bttn18.Text = "Close";
            this.bttn18.UseVisualStyleBackColor = true;
            this.bttn18.Click += new System.EventHandler(this.bttn18_Click);
            // 
            // bttn14
            // 
            this.bttn14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn14.Location = new System.Drawing.Point(74, 232);
            this.bttn14.Name = "bttn14";
            this.bttn14.Size = new System.Drawing.Size(50, 42);
            this.bttn14.TabIndex = 16;
            this.bttn14.Text = ".";
            this.bttn14.UseVisualStyleBackColor = true;
            this.bttn14.Click += new System.EventHandler(this.bttn14_Click);
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(254, 392);
            this.Controls.Add(this.bttn18);
            this.Controls.Add(this.bttn17);
            this.Controls.Add(this.bttn16);
            this.Controls.Add(this.bttn15);
            this.Controls.Add(this.bttn14);
            this.Controls.Add(this.bttn13);
            this.Controls.Add(this.bttn12);
            this.Controls.Add(this.bttn11);
            this.Controls.Add(this.bttn10);
            this.Controls.Add(this.bttn9);
            this.Controls.Add(this.bttn8);
            this.Controls.Add(this.bttn7);
            this.Controls.Add(this.bttn6);
            this.Controls.Add(this.bttn5);
            this.Controls.Add(this.bttn4);
            this.Controls.Add(this.bttn3);
            this.Controls.Add(this.bttn2);
            this.Controls.Add(this.bttn1);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Calculator";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Calculator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDisplay;
        private System.Windows.Forms.Button bttn1;
        private System.Windows.Forms.Button bttn2;
        private System.Windows.Forms.Button bttn3;
        private System.Windows.Forms.Button bttn4;
        private System.Windows.Forms.Button bttn5;
        private System.Windows.Forms.Button bttn6;
        private System.Windows.Forms.Button bttn7;
        private System.Windows.Forms.Button bttn8;
        private System.Windows.Forms.Button bttn9;
        private System.Windows.Forms.Button bttn10;
        private System.Windows.Forms.Button bttn11;
        private System.Windows.Forms.Button bttn12;
        private System.Windows.Forms.Button bttn13;
        private System.Windows.Forms.Button bttn15;
        private System.Windows.Forms.Button bttn16;
        private System.Windows.Forms.Button bttn17;
        private System.Windows.Forms.Button bttn18;
        private System.Windows.Forms.Button bttn14;
    }
}