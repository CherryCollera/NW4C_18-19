﻿using System;

namespace Lab4_Bongco_Static
{
    class Program
    {
 
            static void Main(string[] args)
            {
                Myname name = new Myname();
                Myname nme = new Myname();

                Console.WriteLine(nme.fname + " " + nme.lname);
                Console.ReadLine();
            }
        }
    }
