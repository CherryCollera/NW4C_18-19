﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab4_Bongco_Static
{
    class Myname
    {
        public string fname, lname;
        static Myname()
        {
            System.Console.WriteLine("Static Constructor");
        }
        public Myname()
        {
            fname = "Lenard";
            lname = "Bongco";
        }
    }
}
