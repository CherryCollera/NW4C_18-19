﻿using System;

namespace Lab4_Bongco_Parameterized
{
    class Program
    {
        private static void Main(string[] args)
        {
            Myname name = new Myname("Lenard", "Bongco");
            Console.WriteLine(name.Firstn);
            Console.WriteLine(name.Lastn);
            Console.ReadLine();
        }
    }
}
