﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab4_Bongco_Parameterized
{
    class Myname
    {
        public string Firstn, Lastn
            ;
        public Myname(string p, string s)
        {
            Firstn = p;
            Lastn = s;
        }
    }
}
