﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab4_Bongco_Private
{
    class Myname
    {
        public string fname, lname;
        public Myname(string p, string s)
        {
            fname = p;
            lname = s;
        }
        private Myname()
        {
            System.Console.WriteLine("Private Constructor with no parameters");
        }
    }
}
