﻿using System;

namespace Lab4_Bongco_Private
{
    class Program
    {
       
            static void Main(string[] args)
            {
                Myname name = new Myname("Paul Angelo", "Santos");
                Console.WriteLine(name.fname + " " + name.lname);
                Console.ReadLine();
            }
        }
    }

