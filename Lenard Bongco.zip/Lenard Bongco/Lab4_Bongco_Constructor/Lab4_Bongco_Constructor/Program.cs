﻿using System;

namespace Lab4_Bongco_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Myname name = new Myname();
            Console.WriteLine(name.Firstn);
            Console.WriteLine(name.Lastn);
            Console.ReadLine();
        }
    }
}
