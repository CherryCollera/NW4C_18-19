﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab4_Bongco_Constructor
{

    class Myname
    {

        public string Firstn, Lastn;

        public Myname()
        {
            Firstn = "Lenard";
            Lastn = "Bongco";
        }


    }
}
