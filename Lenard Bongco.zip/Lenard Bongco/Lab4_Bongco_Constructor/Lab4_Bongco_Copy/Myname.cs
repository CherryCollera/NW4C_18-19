﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab4_Bongco_Copy
{
    class Myname
    {
        public string Firstn, Lastn;
        public Myname(string p, string s)
        {
            Firstn = p;
            Lastn = s;
        }
        public Myname(Myname name)
        {
            Firstn = name.Firstn;
            Lastn = name.Lastn;
        }
    }
}
