﻿using System;

namespace Lab4_Bongco_Copy
{
    class Program
    {
        static void Main(string[] args)
        {
            Myname name = new Myname("Lenard", "Bongco");
            Myname nme = new Myname(name);
            Console.WriteLine(name);
            Console.WriteLine("\n" + nme.Firstn + "\n\n" + nme.Lastn);
            Console.ReadLine();
        }
    }
}
