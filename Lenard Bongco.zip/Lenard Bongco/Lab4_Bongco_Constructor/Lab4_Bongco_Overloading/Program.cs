﻿using System;

namespace Lab4_Bongco_Overloading
{
    class Program
    {
        static void Main(string[] args)
        {
            Myname name = new Myname();
            Myname nme = new Myname("Lenard", "Bongco");
            Console.WriteLine(name.Firstn + " " + name.Lastn);
            Console.WriteLine(nme.Firstn + " " + nme.Lastn);
            Console.ReadLine();
        }
    }
}
