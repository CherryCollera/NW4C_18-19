﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab4_Bongco_ConstructorOperation
{
    class Declare
    {
        public static int fnumber, snumber, ans;

        static Declare()
        {
            try
            {
                Console.WriteLine("Enter two numbers to divide :)\n");
                Console.Write("Enter first number:\t");
                fnumber = Convert.ToInt16(Console.ReadLine());
                Console.Write("Enter second number:\t");
                snumber = Convert.ToInt16(Console.ReadLine());
            }
            catch (FormatException fe)
            {
                Console.WriteLine("Error: " + fe.Message);
                throw;
            }
        }
    }
}
