﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab4_Bongco_ConstructorOperation
{
    class Quotient
    {
        public Quotient()
        {
            try
            {
                Declare declare = new Declare();
                Console.WriteLine(declare);
                Declare.ans = Declare.fnumber / Declare.snumber;
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine("Error: " + e.Message);
                throw;
            }
        }
    }
}
