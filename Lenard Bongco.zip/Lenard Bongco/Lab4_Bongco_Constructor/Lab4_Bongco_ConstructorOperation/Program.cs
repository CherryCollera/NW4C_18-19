﻿using System;

namespace Lab4_Bongco_ConstructorOperation
{
    class Program
    {
        static void Main(string[] args)
        {
            Quotient q = new Quotient();
            Console.WriteLine("\nThe quotient is: " + Declare.ans);
            Console.ReadLine();
        }
    }
}
