﻿using System;
namespace ParameterizedConstructor
{
    class Program
    {
        private static void Main(string[] args)
        {
            Sample s = new Sample("Jane", "Doronio");

            Console.WriteLine(s.firstname);
            Console.WriteLine(s.lastname);
            Console.ReadKey();
        }
    }
}
