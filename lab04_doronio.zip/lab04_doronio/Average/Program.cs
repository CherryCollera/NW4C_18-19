﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Average
{
    class Program
    {
        static void Main(string[] args)
        {
            DeclareVar dv = new DeclareVar();
           

            Accept accept = new Accept();
           

            GetAverage ave = new GetAverage();
          
            Console.ReadLine();
        }
    }
}
