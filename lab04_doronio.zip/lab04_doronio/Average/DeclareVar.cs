﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Average
{
    class DeclareVar
    {
        public static int num1, num2, num3, num4, num5;
        public static float average;

        public DeclareVar()
        {

        }
    }
}
