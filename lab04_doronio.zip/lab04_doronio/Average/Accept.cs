﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Average
{
    class Accept
    {
        public Accept()
        {
            Console.Write("Enter 5 grades: \n");
            DeclareVar.num1 = Convert.ToInt32(Console.ReadLine());
            DeclareVar.num2 = Convert.ToInt32(Console.ReadLine());
            DeclareVar.num3 = Convert.ToInt32(Console.ReadLine());
            DeclareVar.num4 = Convert.ToInt32(Console.ReadLine());
            DeclareVar.num5 = Convert.ToInt32(Console.ReadLine());
        }
    }
}
