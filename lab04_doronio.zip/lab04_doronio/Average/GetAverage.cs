﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Average
{
    class GetAverage
    {
        public GetAverage()
        {
            DeclareVar.average = (DeclareVar.num1 + DeclareVar.num2 + DeclareVar.num4 + DeclareVar.num5);
                Console.WriteLine("The average is " + String.Format("{0:F3}", DeclareVar.average) + ".");
        }
    }
}
