﻿using System;
namespace DefaultConstructor
{
    class Program
    {
        private static void Main(string[] args)
        {
            Sample s = new Sample();
            Console.WriteLine(s.firstname);
            Console.WriteLine(s.lastname);
            Console.ReadLine();
        }
    }
}
