﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Default_Constructor
{
    class Sample
    {
         public string firstname, lastname;
         public Sample()
         {
             firstname = "Princess";
             lastname = "Beltran";
         }
    }
}
