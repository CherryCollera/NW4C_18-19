﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Copy_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Copy c = new Copy("Princess", "Beltran");
            Copy c1 = new Copy(c);
            Console.WriteLine(c);
            Console.WriteLine("\n" + c1.firstname + "\n\n" + c1.lastname);
            Console.ReadLine();
        }
    }
}
