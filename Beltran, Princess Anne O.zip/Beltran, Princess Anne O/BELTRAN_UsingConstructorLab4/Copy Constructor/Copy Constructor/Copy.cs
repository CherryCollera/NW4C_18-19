﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Copy_Constructor
{
    class Copy
    {
        public string firstname, lastname;
        public Copy(string x, string y)
        {
            firstname = x;
            lastname = y;

        }
        public Copy(Copy c)
        {
            firstname = c.firstname;
            lastname = c.lastname;
        }
    }
}
