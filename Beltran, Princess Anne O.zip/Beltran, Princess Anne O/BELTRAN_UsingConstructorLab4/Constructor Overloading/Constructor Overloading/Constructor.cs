﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_Overloading
{
    class Constructor
    {
        public string firstname, lastname;
        public Constructor()
        {
            firstname = "Princess";
            lastname = "Beltran";
        }
        public Constructor(string x, string y)
        {
            firstname = x;
            lastname = y;
        }
    }
}
