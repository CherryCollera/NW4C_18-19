﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_Overloading
{
    class Program
    {
        static void Main(string[] args)
        {
            Constructor c = new Constructor();
            Constructor c1 = new Constructor("Princess", "Beltran");
            Console.WriteLine(c.firstname + " " + c.lastname);
            Console.WriteLine(c1.firstname + " " + c1.lastname);
            Console.ReadLine();
        }
    }
}
