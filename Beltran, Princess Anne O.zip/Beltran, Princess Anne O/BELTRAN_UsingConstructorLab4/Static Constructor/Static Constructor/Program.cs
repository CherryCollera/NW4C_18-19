﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Static_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Static s = new Static();
            Static s1 = new Static();
            Console.WriteLine(s1.firstname + " " + s1.lastname);
            Console.ReadLine();
        }
        }
    }

