﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Static_Constructor
{
    class Static
    {
        public string firstname, lastname;

        static Static()
        {
            System.Console.WriteLine("Static Constructor");
        }
        public Static()
        {
            firstname = "Princess";
            lastname = "Beltran";
        }
    }
}
