﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Private_Coonstructor
{
    class Private
    {
        public string firstname, lastname;
        public Private(string x, string y)
        {
            firstname = x;
            lastname = y;
        }
        private Private()
        {
            System.Console.WriteLine("Private constructor with no parameters");
        }
    }
}
