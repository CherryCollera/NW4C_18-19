﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Private_Coonstructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Private p = new Private("Princess", "Beltran");
            Console.WriteLine(p.firstname + " " + p.lastname);
            Console.ReadLine();
        }
    }
}
