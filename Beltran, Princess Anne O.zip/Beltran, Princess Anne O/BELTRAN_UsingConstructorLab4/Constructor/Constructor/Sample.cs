﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor
{
    class Sample
    {
        public string firstname, lastname;
        static Sample()
        {
            System.Console.WriteLine("This is my name:");
        }
        public Sample()
        {
            firstname = "PRINCESS";
            lastname = "BELTRAN";
        }
    }
}
