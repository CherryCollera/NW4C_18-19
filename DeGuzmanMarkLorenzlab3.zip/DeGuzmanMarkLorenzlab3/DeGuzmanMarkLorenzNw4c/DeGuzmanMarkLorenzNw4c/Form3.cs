﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeGuzmanMarkLorenzNw4c
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Declarevar.IntButtonClicked = true;
            Declarevar.DoubleButtonClicked = false;
            Declarevar.FloatButtonClicked = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Declarevar.IntButtonClicked = false;
            Declarevar.DoubleButtonClicked = true;
            Declarevar.FloatButtonClicked = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Declarevar.IntButtonClicked = false;
            Declarevar.DoubleButtonClicked = false;
            Declarevar.FloatButtonClicked = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (txtFirst.Text == "" && txtSecond.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Please Input Some Value in the TextBox", (Declarevar.Title));
            }
            else
            {
                if (Declarevar.IntButtonClicked == true)
                {
                    try
                    {
                        Declarevar.total = System.Convert.ToInt32(txtFirst.Text) + System.Convert.ToInt32(txtSecond.Text);
                        txtFirst.Clear();
                        txtSecond.Clear();
                        System.Windows.Forms.MessageBox.Show("The answer is: " + Declarevar.total, (Declarevar.Title));
                    }
                    catch (System.FormatException)
                    {
                        txtFirst.Clear();
                        txtSecond.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!", (Declarevar.Title));
                    }
                }
                else if (Declarevar.DoubleButtonClicked == true)
                {
                    try
                    {
                        Declarevar.total = System.Convert.ToDouble(txtFirst.Text) + System.Convert.ToDouble(txtSecond.Text);
                        txtFirst.Clear();
                        txtSecond.Clear();
                        System.Windows.Forms.MessageBox.Show("The answer is: " + Declarevar.total, (Declarevar.Title));
                    }
                    catch (System.FormatException)
                    {
                        txtFirst.Clear();
                        txtSecond.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!", (Declarevar.Title));
                    }
                }
                else if (Declarevar.FloatButtonClicked == true)
                {
                    try
                    {
                        Declarevar.total = float.Parse(txtFirst.Text, System.Globalization.CultureInfo.InvariantCulture.NumberFormat) + float.Parse(txtSecond.Text, System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                        txtFirst.Clear();
                        txtSecond.Clear();
                        System.Windows.Forms.MessageBox.Show("The answer is: " + Declarevar.total, (Declarevar.Title));

                    }
                    catch (System.FormatException)
                    {
                        txtFirst.Clear();
                        txtSecond.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!", (Declarevar.Title));
                    }
                }
            }
        }

   
       

        private void button6_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.ShowDialog();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form4 form4 = new Form4();
            form4.ShowDialog();
        }
    }
}

