﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeGuzmanMarkLorenzNw4c
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnnf_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void btndm_Click(object sender, EventArgs e)
        {

        }

        private void btncr_Click(object sender, EventArgs e)
        {
            Calculator form = new Calculator();
            form.Show();
            this.Hide();
        }

    
        private void btncr_Click_1(object sender, EventArgs e)
        {
            Calculator form = new Calculator();
            form.Show();
            this.Hide();
        }

        private void btnnf_Click_1(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void btndm_Click_1(object sender, EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show("NeonTetra");
        }

        private void btncf_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
