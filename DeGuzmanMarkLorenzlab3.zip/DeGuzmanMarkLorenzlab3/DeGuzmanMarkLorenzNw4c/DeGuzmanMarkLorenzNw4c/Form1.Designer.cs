﻿namespace DeGuzmanMarkLorenzNw4c
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btncf = new System.Windows.Forms.Button();
            this.btncal = new System.Windows.Forms.Button();
            this.btnnf = new System.Windows.Forms.Button();
            this.btndm = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btncf
            // 
            this.btncf.Font = new System.Drawing.Font("Arial Narrow", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncf.Location = new System.Drawing.Point(53, 331);
            this.btncf.Margin = new System.Windows.Forms.Padding(4);
            this.btncf.Name = "btncf";
            this.btncf.Size = new System.Drawing.Size(287, 42);
            this.btncf.TabIndex = 9;
            this.btncf.Text = "CLOSE FORM";
            this.btncf.UseVisualStyleBackColor = true;
            this.btncf.Click += new System.EventHandler(this.btncf_Click_1);
            // 
            // btncal
            // 
            this.btncal.Font = new System.Drawing.Font("Arial Narrow", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncal.Location = new System.Drawing.Point(74, 261);
            this.btncal.Margin = new System.Windows.Forms.Padding(4);
            this.btncal.Name = "btncal";
            this.btncal.Size = new System.Drawing.Size(248, 42);
            this.btncal.TabIndex = 8;
            this.btncal.Text = "CALCULATOR";
            this.btncal.UseVisualStyleBackColor = true;
            this.btncal.Click += new System.EventHandler(this.btncr_Click_1);
            // 
            // btnnf
            // 
            this.btnnf.Font = new System.Drawing.Font("Arial Narrow", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnf.Location = new System.Drawing.Point(74, 196);
            this.btnnf.Margin = new System.Windows.Forms.Padding(4);
            this.btnnf.Name = "btnnf";
            this.btnnf.Size = new System.Drawing.Size(248, 42);
            this.btnnf.TabIndex = 7;
            this.btnnf.Text = "NEXT FORM";
            this.btnnf.UseVisualStyleBackColor = true;
            this.btnnf.Click += new System.EventHandler(this.btnnf_Click_1);
            // 
            // btndm
            // 
            this.btndm.Font = new System.Drawing.Font("Arial Narrow", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndm.Location = new System.Drawing.Point(74, 129);
            this.btndm.Margin = new System.Windows.Forms.Padding(4);
            this.btndm.Name = "btndm";
            this.btndm.Size = new System.Drawing.Size(248, 42);
            this.btndm.TabIndex = 6;
            this.btndm.Text = "DISPLAY MESSAGE";
            this.btndm.UseVisualStyleBackColor = true;
            this.btndm.Click += new System.EventHandler(this.btndm_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(36, 47);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(316, 44);
            this.label1.TabIndex = 5;
            this.label1.Text = "Displaying Message";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(388, 450);
            this.Controls.Add(this.btncf);
            this.Controls.Add(this.btncal);
            this.Controls.Add(this.btnnf);
            this.Controls.Add(this.btndm);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btncf;
        private System.Windows.Forms.Button btncal;
        private System.Windows.Forms.Button btnnf;
        private System.Windows.Forms.Button btndm;
        private System.Windows.Forms.Label label1;
    }
}

