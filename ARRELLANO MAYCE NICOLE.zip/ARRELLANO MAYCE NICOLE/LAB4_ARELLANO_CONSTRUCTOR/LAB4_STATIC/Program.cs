﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_STATIC
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample name = new Sample();
            Sample pangalan = new Sample();

            Console.WriteLine(pangalan.fname + " " + pangalan.lname);
            Console.ReadLine();
        }
    }
}
