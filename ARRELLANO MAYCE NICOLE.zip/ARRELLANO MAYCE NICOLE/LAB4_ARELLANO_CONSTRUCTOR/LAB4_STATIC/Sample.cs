﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_STATIC
{
    class Sample
    {
        public string fname, lname;
        static Sample()
        {
            System.Console.WriteLine("Static Constructor");
        }
        public Sample()
        {
            fname = "Maycee Nicole";
            lname = "Arellano";
        }

    }
}
