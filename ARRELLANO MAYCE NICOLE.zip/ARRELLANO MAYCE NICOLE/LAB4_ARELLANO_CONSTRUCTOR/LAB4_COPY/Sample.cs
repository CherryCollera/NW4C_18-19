﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_COPY
{
    class Sample
    {
        public string fname, lname;
        public Sample(string s, string d)
        {
            fname = s;
            lname = d;
        }
        public Sample(Sample name)
        {
            fname = name.fname;
            lname = name.lname;
        }
    }
}
