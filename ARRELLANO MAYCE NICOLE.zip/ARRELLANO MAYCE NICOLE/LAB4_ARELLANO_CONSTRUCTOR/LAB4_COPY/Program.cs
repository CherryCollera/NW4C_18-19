﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_COPY
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample name = new Sample("Maycee Nicole", "Arellano");
            Sample pangalan = new Sample(name);
            Console.WriteLine(name);
            Console.WriteLine("\n" + pangalan.fname + "\n\n" + pangalan.lname);
            Console.ReadLine();
        }
    }
}
