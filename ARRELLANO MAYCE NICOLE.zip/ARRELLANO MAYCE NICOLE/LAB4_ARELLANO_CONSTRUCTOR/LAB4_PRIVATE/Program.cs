﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_PRIVATE
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample name = new Sample("Maycee Nicole", "Arellano");
            Console.WriteLine(name.fname + " " + name.lname);
            Console.ReadLine();
        }
    }
}
