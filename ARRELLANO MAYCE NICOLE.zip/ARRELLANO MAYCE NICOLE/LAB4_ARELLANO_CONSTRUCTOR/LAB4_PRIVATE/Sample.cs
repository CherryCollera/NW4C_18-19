﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_PRIVATE
{
    class Sample
    {
        public string fname, lname;
        public Sample(string s, string d)
        {
            fname = s;
            lname = d;
        }
        private Sample()
        {
            System.Console.WriteLine("Private Constructor with no parameters");
        }

    }
}
