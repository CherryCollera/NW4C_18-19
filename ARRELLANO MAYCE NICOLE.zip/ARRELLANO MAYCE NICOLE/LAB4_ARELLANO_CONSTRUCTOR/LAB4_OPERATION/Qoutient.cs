﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_OPERATION
{
    class Qoutient
    {
        public Qoutient()
        {
            try
            {
                Declare declare = new Declare();
                Console.WriteLine(declare);
                Declare.answer = Declare.firstnumber / Declare.secondnumber;
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine("Error: " + e.Message);
                throw;
            }
        }

    }
}
