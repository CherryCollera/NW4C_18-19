﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_OPERATION
{
    class Program
    {
        static void Main(string[] args)
        {

            Quotient q = new Quotient();
            Console.WriteLine("\nThe quotient is: " + Declare.answer);
            Console.ReadLine();
        }
    }
}
