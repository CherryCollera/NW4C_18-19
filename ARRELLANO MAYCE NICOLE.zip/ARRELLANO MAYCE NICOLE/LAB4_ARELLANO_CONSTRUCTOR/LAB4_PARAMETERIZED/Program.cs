﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_PARAMETERIZED
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample name = new Sample("Maycee Nicole", "Arellano");
            Console.WriteLine(name.fname);
            Console.WriteLine(name.lname);
            Console.ReadLine();

        }

    }
}
