﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_PARAMETERIZED
{
    class Sample
    {
        public string fname, lname;
        public Sample(string s, string d)
        {
            fname = s;
            lname = d;
        }


    }
}
