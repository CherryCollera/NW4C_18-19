﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

        private void Calculator_Load(object sender, EventArgs e)
        {

        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnmultiply_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();
            DeclareVar.divideButtonClicked = false;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.minusButtonClicked = false;
            DeclareVar.multiplyButtonClicked = true;
            
        }

        private void btnminus_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();
            DeclareVar.divideButtonClicked = false;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.minusButtonClicked = true;
            DeclareVar.multiplyButtonClicked = false;
            
        }

        private void btnplus_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();
            DeclareVar.divideButtonClicked = false;
            DeclareVar.plusButtonClicked = true;
            DeclareVar.minusButtonClicked = false;
            DeclareVar.multiplyButtonClicked = false;
           
        }

        private void btndivide_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            DeclareVar.divideButtonClicked = true;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.minusButtonClicked = false;
            DeclareVar.multiplyButtonClicked = false;
           
        }

        private void btnEqual_Click(object sender, EventArgs e)
        {
            if (DeclareVar.plusButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 + double.Parse(txtDisplay.Text);
            }
            else if (DeclareVar.minusButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 - double.Parse(txtDisplay.Text);
            }
            else if (DeclareVar.multiplyButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 * double.Parse(txtDisplay.Text);
            }
            else if (DeclareVar.divideButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 / double.Parse(txtDisplay.Text);
            }

            txtDisplay.Text = DeclareVar.total2.ToString();
            DeclareVar.total1 = 0;
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnOne.Text;
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text +  btnTwo.Text;
        }

        private void bntThree_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnThree.Text;
        }

        private void btnFour_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnFour.Text;
        }

        private void btnFive_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnFive.Text;
        }

        private void btnSix_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnSix.Text;
        }

        private void btnSeven_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnSeven.Text;
        }

        private void btnEight_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnEight.Text;
        }

        private void btnNine_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnNine.Text;
        }

        private void btnZero_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnZero.Text;
        }

        private void btnPeriod_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnPeriod.Text;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
        }
    }
}
