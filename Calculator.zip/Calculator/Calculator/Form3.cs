﻿namespace Calculator
{
    public partial class Form3 : System.Windows.Forms.Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, System.EventArgs e)
        {

        }

        private void btnComputeSum_Click(object sender, System.EventArgs e)
        {
            DeclareVar.n = System.Convert.ToInt32(txtNum1.Text) + System.Convert.ToInt32(txtNum2.Text);
            System.Windows.Forms.MessageBox.Show(System.Convert.ToString(DeclareVar.n), DeclareVar.Stitle);
        }

        private void btnNext_Click(object sender, System.EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
        }

        private void btnClose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void btnInteger_Click(object sender, System.EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show(System.Convert.ToString(DeclareVar.a), DeclareVar.Ititle);
        }

        private void btnDouble_Click(object sender, System.EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show(System.Convert.ToString(DeclareVar.b), DeclareVar.Dotitle);
        }

        private void btnFloat_Click(object sender, System.EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show(System.Convert.ToString(DeclareVar.c), DeclareVar.Ftitle);
        }
    }
}
