﻿namespace Calculator
{
    class DeclareVar
    {
        public static double total1 = 0;
        public static double total2 = 0;
        public  const int a = 15;
        public  const double b = 15.80;
        public  const float c = 15.80f;
        public static string Dmessage = "Hello! Welcome to Windows Form";
        public static string Dtitle = "Display Message";
        public static string Stitle = "Sum";
        public static string Ititle = "Integer";
        public static string Dotitle = "Double";
        public static string Ftitle = "Float";
        public static string Display = "Name Display";
        public static int n;
        
        public static bool minusButtonClicked = false;
        public static bool plusButtonClicked = false;
        public static bool divideButtonClicked = false;
        public static bool multiplyButtonClicked = false;
        // bool equalButtonClicked = false;
    }
}
