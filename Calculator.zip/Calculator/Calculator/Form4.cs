﻿namespace Calculator
{
    public partial class Form4 : System.Windows.Forms.Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, System.EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show(DisplayName.Text, DeclareVar.Display);
        }

        private void btnCancel_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
