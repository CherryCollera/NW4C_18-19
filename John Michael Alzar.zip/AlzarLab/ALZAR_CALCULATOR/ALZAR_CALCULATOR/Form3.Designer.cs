﻿namespace ALZAR_CALCULATOR
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btninteger = new System.Windows.Forms.Button();
            this.btndouble = new System.Windows.Forms.Button();
            this.btnfloat = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tbfirstnumber = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbsecondnumber = new System.Windows.Forms.TextBox();
            this.btncomputesum = new System.Windows.Forms.Button();
            this.btnnextform = new System.Windows.Forms.Button();
            this.btncloseform = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Computer Calculator";
            // 
            // btninteger
            // 
            this.btninteger.Location = new System.Drawing.Point(5, 26);
            this.btninteger.Name = "btninteger";
            this.btninteger.Size = new System.Drawing.Size(199, 23);
            this.btninteger.TabIndex = 1;
            this.btninteger.Text = "Integer";
            this.btninteger.UseVisualStyleBackColor = true;
            this.btninteger.Click += new System.EventHandler(this.btninteger_Click);
            // 
            // btndouble
            // 
            this.btndouble.Location = new System.Drawing.Point(244, 26);
            this.btndouble.Name = "btndouble";
            this.btndouble.Size = new System.Drawing.Size(199, 23);
            this.btndouble.TabIndex = 1;
            this.btndouble.Text = "Double";
            this.btndouble.UseVisualStyleBackColor = true;
            this.btndouble.Click += new System.EventHandler(this.btndouble_Click);
            // 
            // btnfloat
            // 
            this.btnfloat.Location = new System.Drawing.Point(474, 26);
            this.btnfloat.Name = "btnfloat";
            this.btnfloat.Size = new System.Drawing.Size(174, 23);
            this.btnfloat.TabIndex = 1;
            this.btnfloat.Text = "Float";
            this.btnfloat.UseVisualStyleBackColor = true;
            this.btnfloat.Click += new System.EventHandler(this.btnfloat_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Enter First Number:";
            // 
            // tbfirstnumber
            // 
            this.tbfirstnumber.Location = new System.Drawing.Point(115, 55);
            this.tbfirstnumber.Name = "tbfirstnumber";
            this.tbfirstnumber.Size = new System.Drawing.Size(173, 20);
            this.tbfirstnumber.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(311, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Enter Second Number:";
            // 
            // tbsecondnumber
            // 
            this.tbsecondnumber.Location = new System.Drawing.Point(444, 55);
            this.tbsecondnumber.Name = "tbsecondnumber";
            this.tbsecondnumber.Size = new System.Drawing.Size(200, 20);
            this.tbsecondnumber.TabIndex = 3;
            this.tbsecondnumber.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // btncomputesum
            // 
            this.btncomputesum.Location = new System.Drawing.Point(244, 105);
            this.btncomputesum.Name = "btncomputesum";
            this.btncomputesum.Size = new System.Drawing.Size(199, 23);
            this.btncomputesum.TabIndex = 1;
            this.btncomputesum.Text = "Compute Sum";
            this.btncomputesum.UseVisualStyleBackColor = true;
            this.btncomputesum.Click += new System.EventHandler(this.btncomputesum_Click);
            // 
            // btnnextform
            // 
            this.btnnextform.Location = new System.Drawing.Point(244, 134);
            this.btnnextform.Name = "btnnextform";
            this.btnnextform.Size = new System.Drawing.Size(199, 23);
            this.btnnextform.TabIndex = 1;
            this.btnnextform.Text = "Next Form";
            this.btnnextform.UseVisualStyleBackColor = true;
            this.btnnextform.Click += new System.EventHandler(this.btnnextform_Click);
            // 
            // btncloseform
            // 
            this.btncloseform.Location = new System.Drawing.Point(244, 163);
            this.btncloseform.Name = "btncloseform";
            this.btncloseform.Size = new System.Drawing.Size(199, 23);
            this.btncloseform.TabIndex = 1;
            this.btncloseform.Text = "Close Form";
            this.btncloseform.UseVisualStyleBackColor = true;
            this.btncloseform.Click += new System.EventHandler(this.btncloseform_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 261);
            this.Controls.Add(this.tbsecondnumber);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbfirstnumber);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnfloat);
            this.Controls.Add(this.btncloseform);
            this.Controls.Add(this.btnnextform);
            this.Controls.Add(this.btncomputesum);
            this.Controls.Add(this.btndouble);
            this.Controls.Add(this.btninteger);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btninteger;
        private System.Windows.Forms.Button btndouble;
        private System.Windows.Forms.Button btnfloat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbfirstnumber;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbsecondnumber;
        private System.Windows.Forms.Button btncomputesum;
        private System.Windows.Forms.Button btnnextform;
        private System.Windows.Forms.Button btncloseform;
    }
}