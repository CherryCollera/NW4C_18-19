﻿

namespace ALZAR_CALCULATOR
{
    public partial class Calculator : System.Windows.Forms.Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btn1.Text;
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btn2.Text;
        }

        private void button3_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btn3.Text;
        }

        private void button4_Click(object sender, System.EventArgs e)
        {
            Declarevar.total1 = Declarevar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            Declarevar.minusButtonClicked = true;
            Declarevar.plusButtonClicked = true;
            Declarevar.divideButtonClicked = true;
            Declarevar.mulitiplyButtonClicked = true;
        }

        private void button5_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btn4.Text;
        }

        private void button6_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btn5.Text;
        }

        private void button7_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btn6.Text;
        }

        private void button8_Click(object sender, System.EventArgs e)
        {
            Declarevar.total1 = Declarevar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            Declarevar.minusButtonClicked = true;
            Declarevar.plusButtonClicked = false;
            Declarevar.divideButtonClicked = false;
            Declarevar.mulitiplyButtonClicked = false;
        }

        private void button9_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btn7.Text;
        }

        private void button10_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btn8.Text;
        }

        private void Calculator_Load(object sender, System.EventArgs e)
        {

        }

        private void button11_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btn9.Text;
        }

        private void button12_Click(object sender, System.EventArgs e)
        {
            Declarevar.total1 = Declarevar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            Declarevar.mulitiplyButtonClicked = true;
            Declarevar.minusButtonClicked = false;
            Declarevar.plusButtonClicked = false;
            Declarevar.divideButtonClicked = false;
            
        }

        private void button13_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btn0.Text;
        }

        private void button14_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btndot.Text;
        }

        private void button15_Click(object sender, System.EventArgs e)
        {
            txtDisplay.Clear();
        }

        private void button16_Click(object sender, System.EventArgs e)
        {
            Declarevar.total1 = Declarevar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            Declarevar.minusButtonClicked = false;
            Declarevar.plusButtonClicked = false;
            Declarevar.divideButtonClicked = true;
            Declarevar.mulitiplyButtonClicked = false;
        }

        private void btnequal_Click(object sender, System.EventArgs e)
        {
            if (Declarevar.plusButtonClicked == true)
            {
                Declarevar.total2 = Declarevar.total1 + double.Parse(txtDisplay.Text);
            }
            else if (Declarevar.minusButtonClicked == true)
            {
                Declarevar.total2 = Declarevar.total1 - double.Parse(txtDisplay.Text);

            }
            else if (Declarevar.mulitiplyButtonClicked == true)
            {
                Declarevar.total2 = Declarevar.total1 * double.Parse(txtDisplay.Text);
            }
            else if (Declarevar.divideButtonClicked == true)
            {
                Declarevar.total2 = Declarevar.total1 / double.Parse(txtDisplay.Text);
            }

            txtDisplay.Text = Declarevar.total2.ToString();
            Declarevar.total1 = 0;   
                
            
        }

        

        private void btnclose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
