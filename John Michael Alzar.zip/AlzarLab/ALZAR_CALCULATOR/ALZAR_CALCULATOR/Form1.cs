﻿
namespace ALZAR_CALCULATOR
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, System.EventArgs e)
        {

        }

        private void btn2_Click(object sender, System.EventArgs e)
        {
            Form4 form = new Form4();
            form.Show();
        }

        private void btn1_Click(object sender, System.EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show("Hello World!");
        }

        private void Form1_Load(object sender, System.EventArgs e)
        {

        }

        private void btn3_Click(object sender, System.EventArgs e)
        {
            Calculator calcu = new Calculator();
            calcu.Show();
        }

        private void btn4_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
