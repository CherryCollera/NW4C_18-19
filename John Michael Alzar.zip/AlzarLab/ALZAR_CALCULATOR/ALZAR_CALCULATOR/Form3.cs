﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ALZAR_CALCULATOR
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btncloseform_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btninteger_Click(object sender, EventArgs e)
        {
            Declarevar.IntButtonClicked = true;
            Declarevar.DoubleButtonClicked = false;
            Declarevar.FloatButtonClicked = false;
        }

        private void btndouble_Click(object sender, EventArgs e)
        {
            Declarevar.IntButtonClicked = false;
            Declarevar.DoubleButtonClicked = true;
            Declarevar.FloatButtonClicked = false;
        }

        private void btnfloat_Click(object sender, EventArgs e)
        {
            Declarevar.IntButtonClicked = false;
            Declarevar.DoubleButtonClicked = false;
            Declarevar.FloatButtonClicked = true;
        }

        private void btncomputesum_Click(object sender, EventArgs e)
        {
            if (tbfirstnumber.Text == "" && tbsecondnumber.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Please Input Some Value in the TextBox");
            }
            else
            {
                if (Declarevar.IntButtonClicked == true)
                {
                    try
                    {
                        Declarevar.total = System.Convert.ToInt32(tbfirstnumber.Text) + System.Convert.ToInt32(tbsecondnumber.Text);
                        tbfirstnumber.Clear();
                        tbsecondnumber.Clear();
                        System.Windows.Forms.MessageBox.Show("The answer is: " + Declarevar.total);
                    }
                    catch (System.FormatException)
                    {
                        tbfirstnumber.Clear();
                        tbsecondnumber.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!");
                    }
                }
                else if (Declarevar.DoubleButtonClicked == true)
                {
                    try
                    {
                        Declarevar.total = System.Convert.ToDouble(tbfirstnumber.Text) + System.Convert.ToDouble(tbsecondnumber.Text);
                        tbfirstnumber.Clear();
                        tbsecondnumber.Clear();
                        System.Windows.Forms.MessageBox.Show("The answer is: " + Declarevar.total);
                    }
                    catch (System.FormatException)
                    {
                        tbfirstnumber.Clear();
                        tbsecondnumber.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!");
                    }
                }
                else if (Declarevar.FloatButtonClicked == true)
                {
                    try
                    {
                        Declarevar.total = float.Parse(tbfirstnumber.Text, System.Globalization.CultureInfo.InvariantCulture.NumberFormat) + float.Parse(tbsecondnumber.Text, System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                        tbfirstnumber.Clear();
                        tbsecondnumber.Clear();
                        System.Windows.Forms.MessageBox.Show("The answer is: " + Declarevar.total);
                    }
                    catch (System.FormatException)
                    {
                        tbfirstnumber.Clear();
                        tbsecondnumber.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!");
                    }
                }
            }
        }

        private void btnnextform_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
        }
    }
}


