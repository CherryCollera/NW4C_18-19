﻿

namespace ALZAR_CALCULATOR
{
    public partial class Form4 : System.Windows.Forms.Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, System.EventArgs e)
        {

        }

        private void Form4_Load(object sender, System.EventArgs e)
        {

        }

        private void button1_Click(object sender, System.EventArgs e)
        {

        }

        private void btnclose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void btndisplay_Click(object sender, System.EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show("Hello " + textBox1.Text + "!");

        }
    }
}
