﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Myprofile_alzar
{
    class Print
    {
        public void PrintDetails()
        {

        Accept a = new Accept();
        a.AcceptDetails();

            System.Console.Write("Hello " + Accept.firstname + " " + Accept.lastname + "!!!\nYou have created clasess in OOP");
            MyProfile mp = new MyProfile();
        mp.DisplayProfile();
        }
}
}
