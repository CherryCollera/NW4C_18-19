﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Myprofile_alzar
{
    class MyProfile
    {
        public void DisplayProfile()
          
        {
           
            System.Console.WriteLine("\n\n\n\t\t\t\t M Y \t\tP R O F I L E");
            System.Console.WriteLine("Name: \t\t\t" +  Accept.firstname +" " + Accept.lastname +"");
            System.Console.WriteLine("Birthday\t\tOctober 4, 1997");
            System.Console.WriteLine("Course:\t\t\tBS Info tech major" + "in Network" + " and web application");
            System.Console.WriteLine("Year:\t\t\t4th Year");
            System.Console.WriteLine("Section:\t\t\tC");
            System.Console.ReadLine();
        }
}
}