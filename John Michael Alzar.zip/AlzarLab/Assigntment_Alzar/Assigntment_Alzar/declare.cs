﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_Alzar
{
    public class declare
    {
        public static int n1, n2, division, multiply, remainder, subtract, SUM;

        public void declarevar()
        {
            try
            {
                Console.Write("First number: ");
                n1 = Convert.ToInt16(Console.ReadLine());
                Console.Write("Second number: ");
                n2 = Convert.ToInt16(Console.ReadLine());
            }
            catch (System.FormatException ex)
            {
                System.Console.Error.WriteLine("Error:" + ex.Message);
                throw;
            }
        }
    }
}