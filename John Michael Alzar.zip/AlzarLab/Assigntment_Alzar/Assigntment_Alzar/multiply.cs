﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_Alzar
{
    class multiplication
    {
        public void multiply()
        {
            Console.Write(declare.n1 * declare.n2);

        }

    }
}