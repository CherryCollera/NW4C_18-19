﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Assignment_Alzar
{
    class division
    {
        internal void divide()
        {
            
            try
        {
        declare.division = declare.n1 / declare.n2;
            System.Console.WriteLine("\nQoutient = " + declare.division);
            System.Console.ReadLine();
    }
    catch (System.DivideByZeroException ex)
    {
    System.Console.Error.WriteLine("Error:" + ex.Message);
        throw;
        }
     }
  }
}
