﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_Alzar
{
    class Program
    {
        static void Main(string[] args)
        {
            print p = new print();
            p.printed();
            Console.ReadLine();
        }
    }
}