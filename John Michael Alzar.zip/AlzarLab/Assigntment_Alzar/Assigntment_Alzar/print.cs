﻿using Assignment_Alzar;
using System;

namespace Assignment_Alzar
{
    class print
    {
        public void printed()
        {
            string sm;

            declare d = new declare();
            d.declarevar();
            Console.Write("\nSum: ");
            sum a = new sum();
            a.sumdetails();
            Console.ReadLine();
            Console.Write("\nMultiplication: ");
            multiplication m = new multiplication();
            m.multiply();
            Console.ReadLine();
            Console.Write("\nSubtraction: ");
            subtraction s = new subtraction();
            s.subtract();
            Console.ReadLine();
            Console.Write("\nRemainder: ");
            remainder r = new remainder();
            r.remainders();
            Console.ReadLine();
            Console.Write("\nOutient: ");
            division di = new division();
            di.divide();

            
           





        }
    }
}