﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Private_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            
            sample s = new sample("De Leon,", "Carolyn", "B.");
            Console.WriteLine( "\t" + s.ln + " " + s.fn + " " + s.mn);
            Console.ReadLine();
            Console.ReadKey();
        }
    }
}
