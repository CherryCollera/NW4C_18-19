﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Private_Constructor
{
    class sample
    {
        public string ln, fn, mn;
        public sample(string c, string d, string e)
        {
            ln = c;
            fn = d;
            mn = e;
        }
        private sample() 
        {
            System.Console.WriteLine("Private Constructor with no prameters");
            
        }
    }
}
