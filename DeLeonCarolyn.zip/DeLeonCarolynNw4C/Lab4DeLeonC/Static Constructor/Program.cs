﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Static_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Sample sc = new Sample();
            Sample s1 = new Sample();
            Console.WriteLine("\n Age:\t\t" + s1.age + " " + "\n Birthday:\t" + s1.bday + " " + "\n Address:\t" + s1.address);
            Console.ReadLine();
            Console.ReadKey();
        }
    }
}
