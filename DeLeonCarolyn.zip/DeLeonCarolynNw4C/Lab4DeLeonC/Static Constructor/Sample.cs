﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Static_Constructor
{
    class Sample
    {
        public string age, bday, address;

        static Sample()
        {
            System.Console.WriteLine("Static Constructor");
        }
        public Sample()
        {
            age = "19 years old";
            bday = "February 07, 1999";
            address= "Panilao Pilar, Bataan";
            Console.ReadKey();
        }
       
    }
}
