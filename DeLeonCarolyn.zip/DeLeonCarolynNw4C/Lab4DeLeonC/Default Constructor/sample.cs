﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Default_Constructor
{
    class sample
    {
        public string fn, ln;
        public sample() 
     
        {
            fn = "Carolyn";
            ln = "De Leon";
           
            Console.ReadKey();
    }
}
}