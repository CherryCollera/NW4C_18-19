﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Default_Constructor
{
    class Program
    {
       private static void Main(string[] args)
       {
           sample dc = new sample();
           Console.WriteLine("\tFirstName:\t" + dc.fn);
           Console.WriteLine("\tLastName:\t" + dc.ln);
           Console.ReadLine();
           Console.ReadKey();
        }
    }
}
