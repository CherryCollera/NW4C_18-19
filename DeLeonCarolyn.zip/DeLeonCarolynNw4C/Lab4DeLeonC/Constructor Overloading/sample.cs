﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_Overloading
{
    class sample
    {
        public string ln, fn, mn;
        public sample(string c, string d, string e) //private constructor
        {
            ln = c;
            fn = d;
            mn = e;
        }
        private sample()
        {
            System.Console.WriteLine("Private Constructor with no prameters");
        }

        public string course, year;
        public sample(string a, string b) //Declaring Parameterized
        //constructor with Parameters
        {
            course = a;
            year = b;


            Console.ReadKey();
        }
       
    }
}