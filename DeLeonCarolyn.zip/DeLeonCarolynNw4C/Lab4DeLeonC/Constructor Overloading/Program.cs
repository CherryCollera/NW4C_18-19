﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_Overloading
{
    class Program
    {
        static void Main(string[] args)
        {
            sample s = new sample("\tDe Leon,", "Carolyn", "B.");
            sample pc = new sample("\tInformation Technology", "\t4th year");
            Console.WriteLine( "\n\tName:" + s.ln + " " + s.fn + " " + s.mn);
            Console.WriteLine("\n\tCourse:" + pc.course + " " + "\n\n\tYear:" + pc.year);
            Console.ReadLine();
            Console.ReadKey();
        }
        
    }
}
