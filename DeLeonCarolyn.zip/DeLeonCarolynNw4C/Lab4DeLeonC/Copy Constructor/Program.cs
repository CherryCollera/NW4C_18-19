﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Copy_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            sample cc = new sample("De Leon", "Carolyn", "Benavidez");
            sample s = new sample(cc); // Here s details will copied to s1
            Console.WriteLine(s);
            Console.WriteLine("\n\tFull Name:\t" + s.ln + " " + s.fn + " " + s.sn);
            Console.ReadLine();
            Console.ReadKey();
        }
    }
}
