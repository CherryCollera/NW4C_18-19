﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Copy_Constructor
{
    class sample
    {
        public string ln, fn, sn;
        public sample(string x, string y, string z)
        {
            ln = x;
            fn = y;
            sn = z;
        }
        public sample(sample cc) 
        {
           ln= cc.ln;
            fn = cc.fn;
            sn = cc.sn;
            Console.ReadKey();
        }
        }
}
