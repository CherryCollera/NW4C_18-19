﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parameterized_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            sample pc = new sample("Information Technology", "4th year"); 
            Console.WriteLine("\tCourse:\t" + pc.course);
            Console.WriteLine("\tYear:\t" + pc.year);
            Console.ReadLine();
            Console.ReadKey();
        }
    }
}
