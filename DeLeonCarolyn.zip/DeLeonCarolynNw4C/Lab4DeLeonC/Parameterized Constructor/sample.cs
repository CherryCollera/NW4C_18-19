﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parameterized_Constructor
{
    class sample
    {
        public string course, year;
        public sample(string a, string b) 
        {
            course = a;
            year = b;
            Console.ReadKey();
        }
    }
}