﻿namespace AssDeLeonC
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_dismessage = new System.Windows.Forms.Label();
            this.btn_display = new System.Windows.Forms.Button();
            this.btn_nextform = new System.Windows.Forms.Button();
            this.btn_cal = new System.Windows.Forms.Button();
            this.btn_closeform = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_dismessage
            // 
            this.lbl_dismessage.AutoSize = true;
            this.lbl_dismessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dismessage.Location = new System.Drawing.Point(65, 32);
            this.lbl_dismessage.Name = "lbl_dismessage";
            this.lbl_dismessage.Size = new System.Drawing.Size(168, 20);
            this.lbl_dismessage.TabIndex = 0;
            this.lbl_dismessage.Text = "Displaying Message";
            this.lbl_dismessage.Click += new System.EventHandler(this.lbl_dismessage_Click);
            // 
            // btn_display
            // 
            this.btn_display.BackColor = System.Drawing.Color.SeaShell;
            this.btn_display.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_display.Location = new System.Drawing.Point(49, 88);
            this.btn_display.Name = "btn_display";
            this.btn_display.Size = new System.Drawing.Size(206, 29);
            this.btn_display.TabIndex = 1;
            this.btn_display.Text = "Display Message";
            this.btn_display.UseVisualStyleBackColor = false;
            this.btn_display.Click += new System.EventHandler(this.btn_display_Click);
            // 
            // btn_nextform
            // 
            this.btn_nextform.BackColor = System.Drawing.Color.SeaShell;
            this.btn_nextform.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_nextform.Location = new System.Drawing.Point(49, 124);
            this.btn_nextform.Name = "btn_nextform";
            this.btn_nextform.Size = new System.Drawing.Size(206, 29);
            this.btn_nextform.TabIndex = 2;
            this.btn_nextform.Text = "Next Form";
            this.btn_nextform.UseVisualStyleBackColor = false;
            this.btn_nextform.Click += new System.EventHandler(this.btn_nextform_Click);
            // 
            // btn_cal
            // 
            this.btn_cal.BackColor = System.Drawing.Color.SeaShell;
            this.btn_cal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cal.Location = new System.Drawing.Point(49, 159);
            this.btn_cal.Name = "btn_cal";
            this.btn_cal.Size = new System.Drawing.Size(206, 29);
            this.btn_cal.TabIndex = 3;
            this.btn_cal.Text = "Calculator";
            this.btn_cal.UseVisualStyleBackColor = false;
            this.btn_cal.Click += new System.EventHandler(this.btn_cal_Click);
            // 
            // btn_closeform
            // 
            this.btn_closeform.BackColor = System.Drawing.Color.SeaShell;
            this.btn_closeform.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_closeform.Location = new System.Drawing.Point(31, 226);
            this.btn_closeform.Name = "btn_closeform";
            this.btn_closeform.Size = new System.Drawing.Size(241, 29);
            this.btn_closeform.TabIndex = 4;
            this.btn_closeform.Text = "Close Form";
            this.btn_closeform.UseVisualStyleBackColor = false;
            this.btn_closeform.Click += new System.EventHandler(this.btn_closeform_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(304, 322);
            this.Controls.Add(this.btn_closeform);
            this.Controls.Add(this.btn_cal);
            this.Controls.Add(this.btn_nextform);
            this.Controls.Add(this.btn_display);
            this.Controls.Add(this.lbl_dismessage);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_dismessage;
        private System.Windows.Forms.Button btn_display;
        private System.Windows.Forms.Button btn_nextform;
        private System.Windows.Forms.Button btn_cal;
        private System.Windows.Forms.Button btn_closeform;
    }
}

