﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssDeLeonC
{
    class DeclareVar
    {
        public static double total1 = 0;
        public static double total2 = 0;
        public static double total3 = 0;
        public static bool btn_sub = false;
        public static bool btn_add = false;
        public static bool btn_divide = false;
        public static bool btn_mul = false;
        public static bool btn_int_Click = false;
        public static bool btn_double_Click = false;
        public static bool btn_float_Click = false;
        // bool equals ButtonClicked = false;
    }
}
