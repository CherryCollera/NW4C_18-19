﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AssDeLeonC
{
    
    public partial class Calculator : System.Windows.Forms.Form
    {
        

        public Calculator()
        {
            InitializeComponent();
        }

        private void label2_Com_Click(object sender, EventArgs e)
        {

        }

        private void btn2_Click(object sender, EventArgs e)
        {
            txtBox1_ans.Text = txtBox1_ans.Text + btn2.Text;
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            txtBox1_ans.Text = txtBox1_ans.Text + btn1.Text;
        }

        private void txtBox1_ans_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Cal_Click(object sender, EventArgs e)
        {

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtBox1_ans.Text);
            txtBox1_ans.Clear();

            DeclareVar.btn_sub = false;
            DeclareVar.btn_add = true;
            DeclareVar.btn_divide = false;
            DeclareVar.btn_mul = false;

           
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            txtBox1_ans.Text = txtBox1_ans.Text + btn3.Text;
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            txtBox1_ans.Text = txtBox1_ans.Text + btn5.Text;
        }

        private void btn_sub_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtBox1_ans.Text);
            txtBox1_ans.Clear();

            DeclareVar.btn_sub = true;
            DeclareVar.btn_add = false;
            DeclareVar.btn_divide = false;
            DeclareVar.btn_mul = false;
           
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            txtBox1_ans.Text = txtBox1_ans.Text + btn7.Text;
        }

        private void Calculator_Load(object sender, EventArgs e)
        {

        }

        private void btn4_Click(object sender, EventArgs e)
        {
            txtBox1_ans.Text = txtBox1_ans.Text + btn4.Text;
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            txtBox1_ans.Text = txtBox1_ans.Text + btn6.Text;
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            txtBox1_ans.Text = txtBox1_ans.Text + btn8.Text;
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            txtBox1_ans.Text = txtBox1_ans.Text + btn9.Text;
        }

        private void btn_mul_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtBox1_ans.Text);
            txtBox1_ans.Clear();

            DeclareVar.btn_sub = false;
            DeclareVar.btn_add = false;
            DeclareVar.btn_divide = false;
            DeclareVar.btn_mul = true;
          
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            txtBox1_ans.Text = txtBox1_ans.Text + btn0.Text;
        }

        private void btn_period_Click(object sender, EventArgs e)
        {
            txtBox1_ans.Text = txtBox1_ans.Text + btn_period.Text;
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txtBox1_ans.Text = "";
        }

        private void btn_divide_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtBox1_ans.Text);
            txtBox1_ans.Clear();

            DeclareVar.btn_sub = false;
            DeclareVar.btn_add = false;
            DeclareVar.btn_divide = true;
            DeclareVar.btn_mul = false;
           
        }

        private void btn_equal_Click(object sender, EventArgs e)
        {


            if (DeclareVar.btn_add == true)
            {
                DeclareVar.total2 = DeclareVar.total1 + double.Parse(txtBox1_ans.Text);
            }

            else if (DeclareVar.btn_sub == true)
            {
                DeclareVar.total2 = DeclareVar.total1 - double.Parse(txtBox1_ans.Text);
            }

            else if (DeclareVar.btn_mul == true)
            {
                DeclareVar.total2 = DeclareVar.total1 * double.Parse(txtBox1_ans.Text);
            }

            else if (DeclareVar.btn_divide == true)
            {
                DeclareVar.total2 = DeclareVar.total1 / double.Parse(txtBox1_ans.Text);
            }

            txtBox1_ans.Text = DeclareVar.total2.ToString();
            DeclareVar.total1 = 0;

        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
           
            Application.Exit();
        }
    }
}
