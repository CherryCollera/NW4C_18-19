﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AssDeLeonC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbl_dismessage_Click(object sender, EventArgs e)
        {

        }

        private void btn_closeform_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_nextform_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.ShowDialog();
           
        }

        private void btn_cal_Click(object sender, EventArgs e)
        {
            Calculator cal = new Calculator();
            cal.ShowDialog();
        }

        private void btn_display_Click(object sender, EventArgs e)
        {
            MessageBox.Show("WELCOME!!!");
        }
    }
}
