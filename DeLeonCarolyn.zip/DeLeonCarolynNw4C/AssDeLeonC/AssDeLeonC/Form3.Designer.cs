﻿namespace AssDeLeonC
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_cc = new System.Windows.Forms.Label();
            this.btn_int = new System.Windows.Forms.Button();
            this.btn_double = new System.Windows.Forms.Button();
            this.btn_float = new System.Windows.Forms.Button();
            this.lbl_fn = new System.Windows.Forms.Label();
            this.lbl_sn = new System.Windows.Forms.Label();
            this.txtbox_fn = new System.Windows.Forms.TextBox();
            this.btn_comsum = new System.Windows.Forms.Button();
            this.btn_nextform = new System.Windows.Forms.Button();
            this.btn_closeform = new System.Windows.Forms.Button();
            this.btnback3 = new System.Windows.Forms.Button();
            this.txtbox_sn = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_cc
            // 
            this.lbl_cc.AutoSize = true;
            this.lbl_cc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cc.Location = new System.Drawing.Point(260, 21);
            this.lbl_cc.Name = "lbl_cc";
            this.lbl_cc.Size = new System.Drawing.Size(164, 18);
            this.lbl_cc.TabIndex = 0;
            this.lbl_cc.Text = "Computer Calculator";
            // 
            // btn_int
            // 
            this.btn_int.BackColor = System.Drawing.Color.Linen;
            this.btn_int.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_int.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_int.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_int.Location = new System.Drawing.Point(88, 60);
            this.btn_int.Name = "btn_int";
            this.btn_int.Size = new System.Drawing.Size(105, 29);
            this.btn_int.TabIndex = 1;
            this.btn_int.Text = "INTEGER";
            this.btn_int.UseVisualStyleBackColor = false;
            this.btn_int.Click += new System.EventHandler(this.btn_int_Click);
            // 
            // btn_double
            // 
            this.btn_double.BackColor = System.Drawing.Color.Linen;
            this.btn_double.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_double.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_double.Location = new System.Drawing.Point(283, 60);
            this.btn_double.Name = "btn_double";
            this.btn_double.Size = new System.Drawing.Size(105, 29);
            this.btn_double.TabIndex = 2;
            this.btn_double.Text = "DOUBLE";
            this.btn_double.UseVisualStyleBackColor = false;
            this.btn_double.Click += new System.EventHandler(this.btn_double_Click);
            // 
            // btn_float
            // 
            this.btn_float.BackColor = System.Drawing.Color.Linen;
            this.btn_float.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_float.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_float.Location = new System.Drawing.Point(467, 60);
            this.btn_float.Name = "btn_float";
            this.btn_float.Size = new System.Drawing.Size(105, 29);
            this.btn_float.TabIndex = 3;
            this.btn_float.Text = "FLOAT";
            this.btn_float.UseVisualStyleBackColor = false;
            this.btn_float.Click += new System.EventHandler(this.btn_float_Click);
            // 
            // lbl_fn
            // 
            this.lbl_fn.AutoSize = true;
            this.lbl_fn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fn.Location = new System.Drawing.Point(60, 125);
            this.lbl_fn.Name = "lbl_fn";
            this.lbl_fn.Size = new System.Drawing.Size(113, 15);
            this.lbl_fn.TabIndex = 4;
            this.lbl_fn.Text = "Enter First Number:";
            // 
            // lbl_sn
            // 
            this.lbl_sn.AutoSize = true;
            this.lbl_sn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sn.Location = new System.Drawing.Point(329, 125);
            this.lbl_sn.Name = "lbl_sn";
            this.lbl_sn.Size = new System.Drawing.Size(132, 15);
            this.lbl_sn.TabIndex = 5;
            this.lbl_sn.Text = "Enter Second Number:";
            // 
            // txtbox_fn
            // 
            this.txtbox_fn.BackColor = System.Drawing.Color.FloralWhite;
            this.txtbox_fn.Location = new System.Drawing.Point(179, 124);
            this.txtbox_fn.Name = "txtbox_fn";
            this.txtbox_fn.Size = new System.Drawing.Size(125, 20);
            this.txtbox_fn.TabIndex = 6;
            this.txtbox_fn.TextChanged += new System.EventHandler(this.txtbox_fn_TextChanged);
            // 
            // btn_comsum
            // 
            this.btn_comsum.BackColor = System.Drawing.Color.Linen;
            this.btn_comsum.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_comsum.Location = new System.Drawing.Point(179, 175);
            this.btn_comsum.Name = "btn_comsum";
            this.btn_comsum.Size = new System.Drawing.Size(118, 23);
            this.btn_comsum.TabIndex = 8;
            this.btn_comsum.Text = "Compute Sum";
            this.btn_comsum.UseVisualStyleBackColor = false;
            this.btn_comsum.Click += new System.EventHandler(this.btn_comsum_Click);
            // 
            // btn_nextform
            // 
            this.btn_nextform.BackColor = System.Drawing.Color.Linen;
            this.btn_nextform.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_nextform.Location = new System.Drawing.Point(332, 175);
            this.btn_nextform.Name = "btn_nextform";
            this.btn_nextform.Size = new System.Drawing.Size(118, 23);
            this.btn_nextform.TabIndex = 9;
            this.btn_nextform.Text = "Next Form";
            this.btn_nextform.UseVisualStyleBackColor = false;
            this.btn_nextform.Click += new System.EventHandler(this.btn_nextform_Click);
            // 
            // btn_closeform
            // 
            this.btn_closeform.BackColor = System.Drawing.Color.Linen;
            this.btn_closeform.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_closeform.Location = new System.Drawing.Point(332, 226);
            this.btn_closeform.Name = "btn_closeform";
            this.btn_closeform.Size = new System.Drawing.Size(118, 23);
            this.btn_closeform.TabIndex = 10;
            this.btn_closeform.Text = "Exit";
            this.btn_closeform.UseVisualStyleBackColor = false;
            this.btn_closeform.Click += new System.EventHandler(this.btn_closeform_Click);
            // 
            // btnback3
            // 
            this.btnback3.BackColor = System.Drawing.Color.Linen;
            this.btnback3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnback3.Location = new System.Drawing.Point(179, 226);
            this.btnback3.Name = "btnback3";
            this.btnback3.Size = new System.Drawing.Size(118, 23);
            this.btnback3.TabIndex = 11;
            this.btnback3.Text = "Back";
            this.btnback3.UseVisualStyleBackColor = false;
            this.btnback3.Click += new System.EventHandler(this.btnback3_Click);
            // 
            // txtbox_sn
            // 
            this.txtbox_sn.BackColor = System.Drawing.Color.FloralWhite;
            this.txtbox_sn.Location = new System.Drawing.Point(467, 124);
            this.txtbox_sn.Name = "txtbox_sn";
            this.txtbox_sn.Size = new System.Drawing.Size(125, 20);
            this.txtbox_sn.TabIndex = 12;
            this.txtbox_sn.TextChanged += new System.EventHandler(this.txtbox_sn_TextChanged);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(658, 261);
            this.Controls.Add(this.txtbox_sn);
            this.Controls.Add(this.btnback3);
            this.Controls.Add(this.btn_closeform);
            this.Controls.Add(this.btn_nextform);
            this.Controls.Add(this.btn_comsum);
            this.Controls.Add(this.txtbox_fn);
            this.Controls.Add(this.lbl_sn);
            this.Controls.Add(this.lbl_fn);
            this.Controls.Add(this.btn_float);
            this.Controls.Add(this.btn_double);
            this.Controls.Add(this.btn_int);
            this.Controls.Add(this.lbl_cc);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_cc;
        private System.Windows.Forms.Button btn_int;
        private System.Windows.Forms.Button btn_double;
        private System.Windows.Forms.Button btn_float;
        private System.Windows.Forms.Label lbl_fn;
        private System.Windows.Forms.Label lbl_sn;
        private System.Windows.Forms.TextBox txtbox_fn;
        private System.Windows.Forms.Button btn_comsum;
        private System.Windows.Forms.Button btn_nextform;
        private System.Windows.Forms.Button btn_closeform;
        private System.Windows.Forms.Button btnback3;
        private System.Windows.Forms.TextBox txtbox_sn;
    }
}