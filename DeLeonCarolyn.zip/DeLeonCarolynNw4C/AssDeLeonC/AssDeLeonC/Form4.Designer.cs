﻿namespace AssDeLeonC
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_en = new System.Windows.Forms.Label();
            this.lbl_entername = new System.Windows.Forms.Label();
            this.txtbox_enname = new System.Windows.Forms.TextBox();
            this.btn_dis = new System.Windows.Forms.Button();
            this.btn_clo = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_en
            // 
            this.lbl_en.AutoSize = true;
            this.lbl_en.Font = new System.Drawing.Font("Modern No. 20", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_en.Location = new System.Drawing.Point(156, 35);
            this.lbl_en.Name = "lbl_en";
            this.lbl_en.Size = new System.Drawing.Size(205, 29);
            this.lbl_en.TabIndex = 0;
            this.lbl_en.Text = "Entering Name:";
            // 
            // lbl_entername
            // 
            this.lbl_entername.AutoSize = true;
            this.lbl_entername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_entername.Location = new System.Drawing.Point(37, 99);
            this.lbl_entername.Name = "lbl_entername";
            this.lbl_entername.Size = new System.Drawing.Size(132, 20);
            this.lbl_entername.TabIndex = 1;
            this.lbl_entername.Text = "Enter your Name:";
            // 
            // txtbox_enname
            // 
            this.txtbox_enname.Location = new System.Drawing.Point(175, 99);
            this.txtbox_enname.Name = "txtbox_enname";
            this.txtbox_enname.Size = new System.Drawing.Size(282, 20);
            this.txtbox_enname.TabIndex = 2;
            this.txtbox_enname.TextChanged += new System.EventHandler(this.txtbox_enname_TextChanged);
            // 
            // btn_dis
            // 
            this.btn_dis.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_dis.Location = new System.Drawing.Point(41, 143);
            this.btn_dis.Name = "btn_dis";
            this.btn_dis.Size = new System.Drawing.Size(127, 44);
            this.btn_dis.TabIndex = 3;
            this.btn_dis.Text = "Display";
            this.btn_dis.UseVisualStyleBackColor = true;
            this.btn_dis.Click += new System.EventHandler(this.btn_dis_Click);
            // 
            // btn_clo
            // 
            this.btn_clo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clo.Location = new System.Drawing.Point(343, 143);
            this.btn_clo.Name = "btn_clo";
            this.btn_clo.Size = new System.Drawing.Size(127, 44);
            this.btn_clo.TabIndex = 4;
            this.btn_clo.Text = "Close";
            this.btn_clo.UseVisualStyleBackColor = true;
            this.btn_clo.Click += new System.EventHandler(this.btn_clo_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(193, 143);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 44);
            this.button1.TabIndex = 5;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 219);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_clo);
            this.Controls.Add(this.btn_dis);
            this.Controls.Add(this.txtbox_enname);
            this.Controls.Add(this.lbl_entername);
            this.Controls.Add(this.lbl_en);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_en;
        private System.Windows.Forms.Label lbl_entername;
        private System.Windows.Forms.TextBox txtbox_enname;
        private System.Windows.Forms.Button btn_dis;
        private System.Windows.Forms.Button btn_clo;
        private System.Windows.Forms.Button button1;
    }
}