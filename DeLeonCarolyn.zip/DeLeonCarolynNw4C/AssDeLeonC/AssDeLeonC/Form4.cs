﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AssDeLeonC
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btn_dis_Click(object sender, EventArgs e)
        {
            MessageBox.Show(txtbox_enname.Text);
        }

        private void txtbox_enname_TextChanged(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
        }

        private void btn_clo_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            
            Form3 form3 = new Form3();
            this.Hide();
        }
    }
}
