﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AssDeLeonC
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_closeform_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_nextform_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            
            form4.ShowDialog();
           
        }

        private void btnback3_Click(object sender, EventArgs e)
        {
           Form1 form1 = new Form1();
             this.Hide();
        }

        private void btn_int_Click(object sender, EventArgs e)
        {
            DeclareVar.btn_int_Click = true;
            DeclareVar.btn_double_Click = false;
            DeclareVar.btn_float_Click = false;
        }

        private void txtbox_fn_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_double_Click(object sender, EventArgs e)
        {

            DeclareVar.btn_int_Click = false;
            DeclareVar.btn_double_Click = true;
            DeclareVar.btn_float_Click = false;
        }

        private void btn_float_Click(object sender, EventArgs e)
        {

            DeclareVar.btn_int_Click = false;
            DeclareVar.btn_double_Click = false;
            DeclareVar.btn_float_Click = true;
        }

        private void btn_comsum_Click(object sender, EventArgs e)
        {
            if ( txtbox_fn.Text == "" && txtbox_sn.Text == "" )
            {
      
            System.Windows.Forms.MessageBox.Show("ERROR:\n\nInput Value");
                
            }
            else 
            {
                if( DeclareVar.btn_int_Click == true )
                {
                    try {
                        DeclareVar.total3 = System.Convert.ToInt32(txtbox_fn.Text) + 
                           System.Convert.ToInt32(txtbox_sn.Text);
                        txtbox_fn.Clear();
                        txtbox_sn.Clear();
                      
                        System.Windows.Forms.MessageBox.Show("Answer:\t" + DeclareVar.total3);
                    }
                    catch ( System.FormatException )
                    {
                        txtbox_fn.Clear();
                        txtbox_sn.Clear();
                        System.Windows.Forms.MessageBox.Show("Incorrect Format!!");
                    }
                }
                else if (DeclareVar.btn_double_Click== true)
                {
                    try
                    {
                        DeclareVar.total3 = System.Convert.ToDouble(txtbox_fn.Text) + System.Convert.ToDouble(txtbox_sn.Text);
                        txtbox_fn.Clear();
                        txtbox_sn.Clear();
                        System.Windows.Forms.MessageBox.Show("Answer:\t " + DeclareVar.total3);
                    }
                    catch (System.FormatException)
                    {
                        txtbox_fn.Clear();
                        txtbox_sn.Clear();
                        System.Windows.Forms.MessageBox.Show("Incorrect Format!!");
                    }
                }
                else if (DeclareVar.btn_float_Click== true)
                {
                    try
                    {
                        DeclareVar.total3 = float.Parse(txtbox_fn.Text, System.Globalization.CultureInfo.InvariantCulture.NumberFormat) + float.Parse(txtbox_sn.Text, System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                        txtbox_fn.Clear();
                        txtbox_sn.Clear();
                        System.Windows.Forms.MessageBox.Show("Answer:\t " + DeclareVar.total3);
                    }
                    catch (System.FormatException)
                    {
                       txtbox_fn.Clear();
                       txtbox_sn.Clear();
                       System.Windows.Forms.MessageBox.Show("Incorrect Format!!");
                    }
                }
            }
        }







        private void txtbox_sn_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
