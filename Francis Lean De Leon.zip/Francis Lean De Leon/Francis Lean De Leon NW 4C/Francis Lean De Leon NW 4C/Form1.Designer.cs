﻿namespace Francis_Lean_De_Leon_NW_4C
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btndm = new System.Windows.Forms.Button();
            this.btnnf = new System.Windows.Forms.Button();
            this.btncr = new System.Windows.Forms.Button();
            this.btncf = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(346, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Displaying Message";
            // 
            // btndm
            // 
            this.btndm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndm.Location = new System.Drawing.Point(86, 86);
            this.btndm.Name = "btndm";
            this.btndm.Size = new System.Drawing.Size(186, 34);
            this.btndm.TabIndex = 1;
            this.btndm.Text = "DISPLAY MESSAGE";
            this.btndm.UseVisualStyleBackColor = true;
            this.btndm.Click += new System.EventHandler(this.btndm_Click);
            // 
            // btnnf
            // 
            this.btnnf.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnf.Location = new System.Drawing.Point(86, 126);
            this.btnnf.Name = "btnnf";
            this.btnnf.Size = new System.Drawing.Size(186, 34);
            this.btnnf.TabIndex = 2;
            this.btnnf.Text = "NEXT FORM";
            this.btnnf.UseVisualStyleBackColor = true;
            this.btnnf.Click += new System.EventHandler(this.btnnf_Click);
            // 
            // btncr
            // 
            this.btncr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncr.Location = new System.Drawing.Point(86, 166);
            this.btncr.Name = "btncr";
            this.btncr.Size = new System.Drawing.Size(186, 34);
            this.btncr.TabIndex = 3;
            this.btncr.Text = "CALCULATOR";
            this.btncr.UseVisualStyleBackColor = true;
            this.btncr.Click += new System.EventHandler(this.btncr_Click);
            // 
            // btncf
            // 
            this.btncf.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncf.Location = new System.Drawing.Point(34, 251);
            this.btncf.Name = "btncf";
            this.btncf.Size = new System.Drawing.Size(299, 34);
            this.btncf.TabIndex = 4;
            this.btncf.Text = "CLOSE FORM";
            this.btncf.UseVisualStyleBackColor = true;
            this.btncf.Click += new System.EventHandler(this.btncf_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(372, 346);
            this.Controls.Add(this.btncf);
            this.Controls.Add(this.btncr);
            this.Controls.Add(this.btnnf);
            this.Controls.Add(this.btndm);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btndm;
        private System.Windows.Forms.Button btnnf;
        private System.Windows.Forms.Button btncr;
        private System.Windows.Forms.Button btncf;
    }
}