﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Francis_Lean_De_Leon_NW_4C
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnnextform_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
            this.Hide();
        }

        private void btncloseform_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnint_Click(object sender, EventArgs e)
        {
            DeclareVar.IntButtonClicked = true;
            DeclareVar.DoubleButtonClicked = false;
            DeclareVar.FloatButtonClicked = false;
        }

        private void btndou_Click(object sender, EventArgs e)
        {
            DeclareVar.IntButtonClicked = false;
            DeclareVar.DoubleButtonClicked = true;
            DeclareVar.FloatButtonClicked = false;
        }

        private void btnflo_Click(object sender, EventArgs e)
        {
            DeclareVar.IntButtonClicked = false;
            DeclareVar.DoubleButtonClicked = false;
            DeclareVar.FloatButtonClicked = true;
        }

        private void btncompute_Click(object sender, EventArgs e)
        {
            if (txtfirstnum.Text == "" && txtsecondnum.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Please Input Some Value in the TextBox");
            }
            else
            {
                if (DeclareVar.IntButtonClicked == true)
                {
                    try
                    {
                        DeclareVar.total = System.Convert.ToInt32(txtfirstnum.Text) + System.Convert.ToInt32(txtsecondnum.Text);
                        txtfirstnum.Clear();
                        txtsecondnum.Clear();
                        System.Windows.Forms.MessageBox.Show("The answer is: " + DeclareVar.total);
                    }
                    catch (System.FormatException)
                    {
                        txtfirstnum.Clear();
                        txtsecondnum.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!");
                    }
                }
                else if (DeclareVar.DoubleButtonClicked == true)
                {
                    try
                    {
                        DeclareVar.total = System.Convert.ToDouble(txtfirstnum.Text) + System.Convert.ToDouble(txtsecondnum.Text);
                        txtfirstnum.Clear();
                        txtsecondnum.Clear();
                        System.Windows.Forms.MessageBox.Show("The answer is: " + DeclareVar.total);
                    }
                    catch (System.FormatException)
                    {
                        txtfirstnum.Clear();
                        txtsecondnum.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!");
                    }
                }
                else if (DeclareVar.FloatButtonClicked == true)
                {
                    try
                    {
                        DeclareVar.total = float.Parse(txtfirstnum.Text, System.Globalization.CultureInfo.InvariantCulture.NumberFormat) + float.Parse(txtsecondnum.Text, System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                        txtfirstnum.Clear();
                        txtsecondnum.Clear();
                        System.Windows.Forms.MessageBox.Show("The answer is: " + DeclareVar.total);
                    }
                    catch (System.FormatException)
                    {
                        txtfirstnum.Clear();
                        txtsecondnum.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!");
                    }
                }
            }
        }

        private void btnbf_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.ShowDialog();
        }
    }
}
