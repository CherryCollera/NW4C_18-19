﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Francis_Lean_De_Leon_NW_4C
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnnf_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void btndm_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show("Hello World!");
        }

        private void btncr_Click(object sender, EventArgs e)
        {
            Calculator form = new Calculator();
            form.Show();
            this.Hide();
        }

        private void btncf_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
