﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operation
{
    class Addtion
    {
        public Addtion()
        {
            DeclareVariable var = new DeclareVariable();

            Console.WriteLine(var);
            DeclareVariable.add = DeclareVariable.num1 + DeclareVariable.num2;
            Console.ReadLine();
        }
    }
}
