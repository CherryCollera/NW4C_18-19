﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operation
{
    class DeclareVariable
    {
        public static int num1, num2, add;
        public DeclareVariable()
        {
            try
            {
                Console.Write("Enter first number:\t");
                num1 = Convert.ToInt16(Console.ReadLine());
                Console.Write("Enter Second number:\t");
                num2 = Convert.ToInt16(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("User input is invalid");
            }
        }
    }
}
