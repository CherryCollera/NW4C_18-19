﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_De_Leon_Francis
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Cherry";
            lastname = "Collera";
        }

    }
}
