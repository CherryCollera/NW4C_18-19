﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation
{
    class DeclareVar
    {
        public static int a, b, diff;

        public DeclareVar()
        {
            try
            {
                Console.Write("Enter first number:\t");
                a = Convert.ToInt16(Console.ReadLine());
                Console.Write("Enter second number:\t");
                b = Convert.ToInt16(Console.ReadLine());
            }

            catch (FormatException)
            {
                Console.WriteLine("User input is Invalid..");
            }
            Console.ReadKey();

        }
    }
}
