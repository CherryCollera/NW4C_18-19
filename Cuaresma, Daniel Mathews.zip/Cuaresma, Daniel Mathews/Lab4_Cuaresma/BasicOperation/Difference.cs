﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation
{
    class Difference
    {
        public Difference()
        {
            DeclareVar dv = new DeclareVar();
            Console.WriteLine(dv);
            DeclareVar.diff = DeclareVar.a - DeclareVar.b;
            Console.ReadLine();
        }
    }
}
