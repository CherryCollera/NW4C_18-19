﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication5
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int number = 25;
            MessageBox.Show(number.ToString());

        }

        private void button2_Click(object sender, EventArgs e)
        {
            float number = 25.78F;
            MessageBox.Show(number.ToString());

        }

        private void button3_Click(object sender, EventArgs e)
        {
            double number = 25.7889;
            MessageBox.Show(number.ToString());

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int firstTextboxNumber, secondTextboxNumber, sum;
            firstTextboxNumber = int.Parse(tbFirstNumber.Text); // Parse - to convert the text from the textbox into an integer, we need an integer Parse
            secondTextboxNumber = int.Parse(tbSecondNumber.Text);
            sum = firstTextboxNumber + secondTextboxNumber;
            MessageBox.Show("Sum is " + sum.ToString());

        }

        private void tbFirstNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.Show();

        }

        private void tbSecondNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
