﻿
namespace PrivateConstructor
{
    class PrivateCons
    {
        public string fn, ln;
        public PrivateCons(string a, string b)
        {
            fn = a;
            ln = b;
        }
        private PrivateCons()
        {
            System.Console.WriteLine("Private Constructors with no Parameters.");
        }
    }
}
