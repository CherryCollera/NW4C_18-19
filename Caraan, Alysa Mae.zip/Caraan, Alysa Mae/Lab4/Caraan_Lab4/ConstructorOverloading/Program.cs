﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_Overloading
{
    class Program
    {
        static void Main(string[] args)
        {
            ConstructorOverloading consoverloading = new ConstructorOverloading();
            ConstructorOverloading consover1 = new ConstructorOverloading("CARAAN", "ALYSA MAE");

            Console.WriteLine(consoverloading.fn + " " + consoverloading.ln);
            Console.WriteLine(consover1.fn + " " + consover1.ln);
            Console.ReadLine();

        }
    }
}
