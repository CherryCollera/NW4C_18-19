﻿
namespace Constructor_Overloading
{
    class ConstructorOverloading
    {
        public string fn, ln;

        public ConstructorOverloading()
        {
            fn = "ALYSA MAE";
            ln = "CARAAN";
        }
        public ConstructorOverloading(string a, string b)
        {
            fn = a;
            ln = b;

        }
    }
}
