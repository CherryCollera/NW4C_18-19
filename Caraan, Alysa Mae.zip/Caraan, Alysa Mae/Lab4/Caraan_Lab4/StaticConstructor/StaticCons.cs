﻿
namespace Static_Constructor
{
    class StaticCons
    {
        public string fn, ln;

        static StaticCons()
        {
            System.Console.WriteLine("Static Constructor");
        }
        public StaticCons()
        {
            fn = "ALYSA MAE";
            ln = "CARAAN";
        }
    }
}
