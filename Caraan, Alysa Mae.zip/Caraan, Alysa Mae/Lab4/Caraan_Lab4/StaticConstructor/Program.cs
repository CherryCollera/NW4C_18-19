﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Static_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            StaticCons statcons = new StaticCons();
            StaticCons stat1 = new StaticCons();
            Console.WriteLine(stat1.fn + " " + stat1.ln);
            Console.ReadKey();
        }
    }
}
