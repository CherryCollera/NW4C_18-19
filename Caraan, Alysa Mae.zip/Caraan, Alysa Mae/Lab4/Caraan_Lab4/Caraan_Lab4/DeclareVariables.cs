﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation
{

    class DeclareVariables
    {
        public static int a, b, sum;

        public DeclareVariables()
        {
            try
            {

                Console.Write("Enter first number:\t\t\t");
                DeclareVariables.a = Convert.ToInt16(Console.ReadLine());

                Console.Write("Enter second number:\t\t\t");
                DeclareVariables.b = Convert.ToInt16(Console.ReadLine());
            }
        
            catch (System.FormatException e)
            {
                Console.Error.WriteLine(e.Message);
            }
        }
    }
}