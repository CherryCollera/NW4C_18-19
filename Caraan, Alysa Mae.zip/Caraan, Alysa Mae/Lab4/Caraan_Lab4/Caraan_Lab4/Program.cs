﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation
{
    class Program
    {
        static void Main(string[] args)
        {
            Constructor con = new Constructor();
            Console.WriteLine("Sum is: \t\t\t\t" + DeclareVariables.sum);
            Console.ReadKey();
        }
    }
}
