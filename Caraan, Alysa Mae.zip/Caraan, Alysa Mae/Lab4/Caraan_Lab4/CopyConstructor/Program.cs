﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyConstructor
{
    class Program
    {
        static void Main(string[] args)
        {
            CopyCons copycon = new CopyCons("ALYSA MAE", "CARAAN");
            CopyCons copy1 = new CopyCons(copycon);
            Console.WriteLine(copycon);
            Console.WriteLine("\n" + copy1.fn + "\n\n" + copy1.ln);
            Console.ReadKey();
        }
    }
}
