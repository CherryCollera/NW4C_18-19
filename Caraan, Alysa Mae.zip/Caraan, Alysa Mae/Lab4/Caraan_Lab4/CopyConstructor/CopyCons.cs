﻿
namespace CopyConstructor
{
    class CopyCons
    {
        public string fn, ln;
        public CopyCons(string a, string b)
        {
            fn = a;
            ln = b;
        }
        public CopyCons(CopyCons CopyCons)
        {
            fn = CopyCons.fn;
            ln = CopyCons.ln;
        }
    }
}
