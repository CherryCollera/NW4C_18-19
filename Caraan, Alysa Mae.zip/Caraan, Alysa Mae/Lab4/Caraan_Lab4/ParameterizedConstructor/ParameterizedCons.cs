﻿
namespace ParameterizedConstructor
{
    class ParameterizedCons
    {
        public string fn, ln;
        public ParameterizedCons(string a, string b)
        {
            fn = a;
            ln = b;
        }
    }
}
