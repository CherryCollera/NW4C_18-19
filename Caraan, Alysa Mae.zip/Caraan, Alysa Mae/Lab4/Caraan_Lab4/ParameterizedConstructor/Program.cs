﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParameterizedConstructor
{
    class Program
    {
        static void Main(string[] args)
        {
            ParameterizedCons paramcons = new ParameterizedCons("ALYSA MAE", "CARAAN");

            Console.WriteLine(paramcons.fn);
            Console.WriteLine(paramcons.ln);
            Console.ReadLine();


        }
    }
}
