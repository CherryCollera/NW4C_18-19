﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Default_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            DefaultCons defcons = new DefaultCons();
            Console.WriteLine(defcons.fn);
            Console.WriteLine(defcons.ln);
            Console.ReadLine();
        }
    }
}
