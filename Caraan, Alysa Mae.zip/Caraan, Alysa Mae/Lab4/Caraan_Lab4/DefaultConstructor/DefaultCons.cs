﻿
namespace Default_Constructor
{
    class DefaultCons
    {
        public string fn, ln;
        public DefaultCons()
        {
            fn = "ALYSA MAE";
            ln = "CARAAN";
        }
    }
}
