﻿namespace Caraan_Calculator
{
    public partial class Form4 : System.Windows.Forms.Form
    {
        //START --- TO DRAG/MOVE NONE BORDER STYE :)))
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(System.IntPtr hWnd, int Msg, int wParam, int LPAR);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        const int WM_NCLBUTTONDOWN = 0xA1;
        const int HT_CAPTION = 0x2;

        private void move_window(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        //END --- TO DRAG/MOVE NONE BORDER STYE :)))

        public Form4()
        {
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(move_window); //TO DRAG/MOVE NONE BORDER STYE :)))
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, System.EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show("Hello " + tbName.Text + "!", "Displaying Name");
            tbName.Clear();
        }

        private void btnClosef4_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void tbName_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbName_TextChanged(object sender, System.EventArgs e)
        {
            
        }
    }
}
