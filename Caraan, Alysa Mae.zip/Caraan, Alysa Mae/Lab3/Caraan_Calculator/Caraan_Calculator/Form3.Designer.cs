﻿namespace Caraan_Calculator
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInteger = new System.Windows.Forms.Button();
            this.btnDouble = new System.Windows.Forms.Button();
            this.btnFloat = new System.Windows.Forms.Button();
            this.btnComputesum = new System.Windows.Forms.Button();
            this.btnNextf3 = new System.Windows.Forms.Button();
            this.btnClosef3 = new System.Windows.Forms.Button();
            this.tbFirstnum = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tbSecondnum = new System.Windows.Forms.TextBox();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnEquals = new System.Windows.Forms.Button();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnInteger
            // 
            this.btnInteger.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInteger.Location = new System.Drawing.Point(15, 62);
            this.btnInteger.Name = "btnInteger";
            this.btnInteger.Size = new System.Drawing.Size(170, 31);
            this.btnInteger.TabIndex = 0;
            this.btnInteger.Text = "Integer";
            this.btnInteger.UseVisualStyleBackColor = true;
            this.btnInteger.Click += new System.EventHandler(this.btnInteger_Click);
            // 
            // btnDouble
            // 
            this.btnDouble.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDouble.Location = new System.Drawing.Point(191, 62);
            this.btnDouble.Name = "btnDouble";
            this.btnDouble.Size = new System.Drawing.Size(170, 31);
            this.btnDouble.TabIndex = 1;
            this.btnDouble.Text = "Double";
            this.btnDouble.UseVisualStyleBackColor = true;
            this.btnDouble.Click += new System.EventHandler(this.btnDouble_Click);
            // 
            // btnFloat
            // 
            this.btnFloat.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFloat.Location = new System.Drawing.Point(367, 62);
            this.btnFloat.Name = "btnFloat";
            this.btnFloat.Size = new System.Drawing.Size(170, 31);
            this.btnFloat.TabIndex = 2;
            this.btnFloat.Text = "Float";
            this.btnFloat.UseVisualStyleBackColor = true;
            this.btnFloat.Click += new System.EventHandler(this.btnFloat_Click);
            // 
            // btnComputesum
            // 
            this.btnComputesum.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComputesum.Location = new System.Drawing.Point(165, 165);
            this.btnComputesum.Name = "btnComputesum";
            this.btnComputesum.Size = new System.Drawing.Size(224, 31);
            this.btnComputesum.TabIndex = 5;
            this.btnComputesum.Text = "Compute Sum";
            this.btnComputesum.UseVisualStyleBackColor = true;
            this.btnComputesum.Click += new System.EventHandler(this.btnComputesum_Click);
            // 
            // btnNextf3
            // 
            this.btnNextf3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextf3.Location = new System.Drawing.Point(165, 203);
            this.btnNextf3.Name = "btnNextf3";
            this.btnNextf3.Size = new System.Drawing.Size(224, 31);
            this.btnNextf3.TabIndex = 6;
            this.btnNextf3.Text = "Next Form";
            this.btnNextf3.UseVisualStyleBackColor = true;
            this.btnNextf3.Click += new System.EventHandler(this.btnNextf3_Click);
            // 
            // btnClosef3
            // 
            this.btnClosef3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClosef3.Location = new System.Drawing.Point(165, 242);
            this.btnClosef3.Name = "btnClosef3";
            this.btnClosef3.Size = new System.Drawing.Size(224, 31);
            this.btnClosef3.TabIndex = 7;
            this.btnClosef3.Text = "Close Form";
            this.btnClosef3.UseVisualStyleBackColor = true;
            this.btnClosef3.Click += new System.EventHandler(this.btnClosef3_Click);
            // 
            // tbFirstnum
            // 
            this.tbFirstnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFirstnum.Location = new System.Drawing.Point(145, 78);
            this.tbFirstnum.Name = "tbFirstnum";
            this.tbFirstnum.Size = new System.Drawing.Size(110, 21);
            this.tbFirstnum.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Kozuka Gothic Pr6N H", 15F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(153, 1);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(248, 37);
            this.label6.TabIndex = 10;
            this.label6.Text = "COMPUTER CALCULATOR";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Lavender;
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.tbSecondnum);
            this.panel3.Controls.Add(this.btnNext);
            this.panel3.Controls.Add(this.btnEquals);
            this.panel3.Controls.Add(this.tbFirstnum);
            this.panel3.Location = new System.Drawing.Point(3, 42);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(546, 251);
            this.panel3.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Lavender;
            this.label4.Font = new System.Drawing.Font("Arial", 9.5F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(263, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 16);
            this.label4.TabIndex = 21;
            this.label4.Text = "Enter Second Number:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Lavender;
            this.label7.Font = new System.Drawing.Font("Arial", 9.5F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(9, 81);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 16);
            this.label7.TabIndex = 20;
            this.label7.Text = "Enter First Number:";
            // 
            // tbSecondnum
            // 
            this.tbSecondnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSecondnum.Location = new System.Drawing.Point(420, 78);
            this.tbSecondnum.Name = "tbSecondnum";
            this.tbSecondnum.Size = new System.Drawing.Size(110, 21);
            this.tbSecondnum.TabIndex = 4;
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.Location = new System.Drawing.Point(9, 311);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(108, 43);
            this.btnNext.TabIndex = 18;
            this.btnNext.Text = "Close";
            this.btnNext.UseVisualStyleBackColor = false;
            // 
            // btnEquals
            // 
            this.btnEquals.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnEquals.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEquals.Location = new System.Drawing.Point(123, 311);
            this.btnEquals.Name = "btnEquals";
            this.btnEquals.Size = new System.Drawing.Size(103, 43);
            this.btnEquals.TabIndex = 17;
            this.btnEquals.Text = "=";
            this.btnEquals.UseVisualStyleBackColor = false;
            // 
            // Form3
            // 
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(552, 296);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnClosef3);
            this.Controls.Add(this.btnNextf3);
            this.Controls.Add(this.btnComputesum);
            this.Controls.Add(this.btnFloat);
            this.Controls.Add(this.btnDouble);
            this.Controls.Add(this.btnInteger);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnInteger;
        private System.Windows.Forms.Button btnDouble;
        private System.Windows.Forms.Button btnFloat;
        private System.Windows.Forms.Button btnComputesum;
        private System.Windows.Forms.Button btnNextf3;
        private System.Windows.Forms.Button btnClosef3;
        private System.Windows.Forms.TextBox tbFirstnum;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnEquals;
        private System.Windows.Forms.TextBox tbSecondnum;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
    }
}