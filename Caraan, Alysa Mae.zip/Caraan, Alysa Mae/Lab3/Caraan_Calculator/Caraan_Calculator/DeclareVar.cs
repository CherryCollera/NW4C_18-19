﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caraan_Calculator
{
    class DeclareVar
    {
        public static double total1 = 0;
        public static double total2 = 0;
        public static bool btnsubClicked = false;
        public static bool btnaddClicked = false;
        public static bool btnmulClicked = false;
        public static bool btndivClicked = false;
        public static bool btnIntegerClicked = false;
        public static bool btnDoubleClicked = false;
        public static bool btnFloatClicked = false;
        //bool btnEqualsClicked = false;
    }
}
