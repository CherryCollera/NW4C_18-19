﻿namespace Caraan_Calculator
{
    public partial class Form3 : System.Windows.Forms.Form
    {
        //START --- TO DRAG/MOVE NONE BORDER STYE :)))
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(System.IntPtr hWnd, int Msg, int wParam, int LPAR);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        const int WM_NCLBUTTONDOWN = 0xA1;
        const int HT_CAPTION = 0x2;

        private void move_window(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        //END --- TO DRAG/MOVE NONE BORDER STYE :)))

        public Form3()
        {
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(move_window); //TO DRAG/MOVE NONE BORDER STYE :)))
            InitializeComponent();
        }

        private void Form3_Load(object sender, System.EventArgs e)
        {

        }

        private void label6_Click(object sender, System.EventArgs e)
        {

        }

        private void btnClosef3_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void btnInteger_Click(object sender, System.EventArgs e)
        {
            btnInteger.BackColor = System.Drawing.Color.LightSeaGreen;
            btnInteger.ForeColor = System.Drawing.Color.White;
            btnDouble.BackColor = System.Windows.Forms.Control.DefaultBackColor;
            btnDouble.ForeColor = System.Windows.Forms.Control.DefaultForeColor;
            btnFloat.BackColor = System.Windows.Forms.Control.DefaultBackColor;
            btnFloat.ForeColor = System.Windows.Forms.Control.DefaultForeColor;
            DeclareVar.btnIntegerClicked = true;
            DeclareVar.btnDoubleClicked = false;
            DeclareVar.btnFloatClicked = false;
        }

        private void btnDouble_Click(object sender, System.EventArgs e)
        {
            btnInteger.BackColor = System.Windows.Forms.Control.DefaultBackColor;
            btnInteger.ForeColor = System.Windows.Forms.Control.DefaultForeColor;
            btnDouble.BackColor = System.Drawing.Color.LightSeaGreen;
            btnDouble.ForeColor = System.Drawing.Color.White;
            btnFloat.BackColor = System.Windows.Forms.Control.DefaultBackColor;
            btnFloat.ForeColor = System.Windows.Forms.Control.DefaultForeColor;
            DeclareVar.btnIntegerClicked = false;
            DeclareVar.btnDoubleClicked = true;
            DeclareVar.btnFloatClicked = false;
        }

        private void btnFloat_Click(object sender, System.EventArgs e)
        {
            btnInteger.BackColor = System.Windows.Forms.Control.DefaultBackColor;
            btnInteger.ForeColor = System.Windows.Forms.Control.DefaultForeColor;
            btnDouble.BackColor = System.Windows.Forms.Control.DefaultBackColor;
            btnDouble.ForeColor = System.Windows.Forms.Control.DefaultForeColor;
            btnFloat.BackColor = System.Drawing.Color.LightSeaGreen;
            btnFloat.ForeColor = System.Drawing.Color.White;
            DeclareVar.btnIntegerClicked = false;
            DeclareVar.btnDoubleClicked = false;
            DeclareVar.btnFloatClicked = true;
        }

        private void btnComputesum_Click(object sender, System.EventArgs e)
        {
            if (DeclareVar.btnIntegerClicked == true)
            {
                DeclareVar.total1 = DeclareVar.total1 + int.Parse(tbFirstnum.Text);
                System.Windows.Forms.MessageBox.Show("Sum is " + (DeclareVar.total2 = DeclareVar.total1 + int.Parse(tbSecondnum.Text)), "Answer in Integer");
                tbFirstnum.Clear();
                tbSecondnum.Clear();
            }

            else if (DeclareVar.btnDoubleClicked == true)
            {
                DeclareVar.total1 = DeclareVar.total1 + double.Parse(tbFirstnum.Text);
                System.Windows.Forms.MessageBox.Show("Sum is " + (DeclareVar.total2 = DeclareVar.total1 + double.Parse(tbSecondnum.Text)), "Answer in Integer");
                tbFirstnum.Clear();
                tbSecondnum.Clear();
            }

            else if (DeclareVar.btnFloatClicked == true)
            {
                DeclareVar.total1 = DeclareVar.total1 + float.Parse(tbFirstnum.Text);
                System.Windows.Forms.MessageBox.Show("Sum is " + (DeclareVar.total2 = DeclareVar.total1 + float.Parse(tbSecondnum.Text)), "Answer in Integer");
                tbFirstnum.Clear();
                tbSecondnum.Clear();
            }
            DeclareVar.total1 = 0;
            DeclareVar.total2 = 0;
        }

        private void btnNextf3_Click(object sender, System.EventArgs e)
        {

        }
    }
}
