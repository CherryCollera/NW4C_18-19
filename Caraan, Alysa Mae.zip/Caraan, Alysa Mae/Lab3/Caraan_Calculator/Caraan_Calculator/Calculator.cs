﻿namespace Caraan_Calculator
{
    public partial class Calculator : System.Windows.Forms.Form
    {
        //START --- TO DRAG/MOVE NONE BORDER STYE :)))
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(System.IntPtr hWnd, int Msg, int wParam, int LPAR);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        const int WM_NCLBUTTONDOWN = 0xA1;
        const int HT_CAPTION = 0x2;

        private void move_window(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        //END --- TO DRAG/MOVE NONE BORDER STYE :)))
        
        public Calculator()
        {
            InitializeComponent();
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(move_window); //TO DRAG/MOVE NONE BORDER STYE :)))
            tbdisplay.ForeColor = System.Drawing.SystemColors.GrayText;
            //tbdisplay.Text = "0";
            //this.tbdisplay.Leave += new System.EventHandler(this.tbdisplay_Leave);
            //this.tbdisplay.Enter += new System.EventHandler(this.tbdisplay_Enter);
        }
        
        //NUMBER BUTTONS
        private void btn1_Click(object sender, System.EventArgs e)
        {
            lbl0.Hide();
            tbdisplay.Text = tbdisplay.Text + btn1.Text;
        }

        private void btn2_Click(object sender, System.EventArgs e)
        {
            lbl0.Hide();
            tbdisplay.Text = tbdisplay.Text + btn2.Text;
        }

        private void btn3_Click(object sender, System.EventArgs e)
        {
            lbl0.Hide();
            tbdisplay.Text = tbdisplay.Text + btn3.Text;
        }

        private void btn4_Click(object sender, System.EventArgs e)
        {
            lbl0.Hide();
            tbdisplay.Text = tbdisplay.Text + btn4.Text;
        }

        private void btn5_Click(object sender, System.EventArgs e)
        {
            lbl0.Hide();
            tbdisplay.Text = tbdisplay.Text + btn5.Text;
        }

        private void btn6_Click(object sender, System.EventArgs e)
        {
            lbl0.Hide();
            tbdisplay.Text = tbdisplay.Text + btn6.Text;
        }

        private void btn7_Click(object sender, System.EventArgs e)
        {
            lbl0.Hide();
            tbdisplay.Text = tbdisplay.Text + btn7.Text;
        }

        private void btn8_Click(object sender, System.EventArgs e)
        {
            lbl0.Hide();
            tbdisplay.Text = tbdisplay.Text + btn8.Text;
        }

        private void btn9_Click(object sender, System.EventArgs e)
        {
            lbl0.Hide();
            tbdisplay.Text = tbdisplay.Text + btn9.Text;
        }

        private void btn0_Click(object sender, System.EventArgs e)
        {
            lbl0.Hide();
            tbdisplay.Text = tbdisplay.Text + btn0.Text;
        }

        private void btnpoint_Click(object sender, System.EventArgs e)
        {
            lbl0.Hide();
            tbdisplay.Text = tbdisplay.Text + btnpoint.Text;
        }

        private void btnclear_Click(object sender, System.EventArgs e)
        {
            tbdisplay.Clear();
            lbl0.Show();
        }

        //OPERATOR BUTTONS
        private void btnadd_Click(object sender, System.EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(tbdisplay.Text);
            tbdisplay.Clear();

            DeclareVar.btnaddClicked = true;
            DeclareVar.btnsubClicked = false;
            DeclareVar.btnmulClicked = false;
            DeclareVar.btndivClicked = false;
        }

        private void btnsub_Click(object sender, System.EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(tbdisplay.Text);
            tbdisplay.Clear();

            DeclareVar.btnaddClicked = false;
            DeclareVar.btnsubClicked = true;
            DeclareVar.btnmulClicked = false;
            DeclareVar.btndivClicked = false;
        }

        private void btnmul_Click(object sender, System.EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(tbdisplay.Text);
            tbdisplay.Clear();

            DeclareVar.btnaddClicked = false;
            DeclareVar.btnsubClicked = false;
            DeclareVar.btnmulClicked = true;
            DeclareVar.btndivClicked = false;
        }

        private void btndiv_Click(object sender, System.EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(tbdisplay.Text);
            tbdisplay.Clear();

            DeclareVar.btnaddClicked = false;
            DeclareVar.btnsubClicked = false;
            DeclareVar.btnmulClicked = false;
            DeclareVar.btndivClicked = true;
        }

        private void Calculator_Load(object sender, System.EventArgs e)
        {
           
        }

        private void tbdisplay_TextChanged(object sender, System.EventArgs e)
        {

        }

        /*private void tbdisplay_Leave(object sender, System.EventArgs e)
        {
            if (tbdisplay.Text.Length == 0)
            {
                tbdisplay.Text = "0";
                tbdisplay.ForeColor = System.Drawing.SystemColors.GrayText;
            }
        }

        private void tbdisplay_Enter(object sender, System.EventArgs e)
        {
            if (tbdisplay.Text == "")
            {
                tbdisplay.Text = "0";
                tbdisplay.ForeColor = System.Drawing.SystemColors.WindowText;
            }
        }*/

        private void tbdisplay_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            e.KeyChar = (char)(0);
        }

        private void btnClose_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void btnEquals_Click_1(object sender, System.EventArgs e)
        {
            if (DeclareVar.btnaddClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 + double.Parse(tbdisplay.Text);
            }
            else if (DeclareVar.btnsubClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 - double.Parse(tbdisplay.Text);
            }
            else if (DeclareVar.btnmulClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 * double.Parse(tbdisplay.Text);
            }
            else if (DeclareVar.btndivClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 / double.Parse(tbdisplay.Text);
            }

            tbdisplay.Text = DeclareVar.total2.ToString();
            DeclareVar.total1 = 0;
        }
    }
}
