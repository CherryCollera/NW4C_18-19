﻿namespace Caraan_Calculator
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        //START --- TO DRAG/MOVE NONE BORDER STYE :)))
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(System.IntPtr hWnd, int Msg, int wParam, int LPAR);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        const int WM_NCLBUTTONDOWN = 0xA1;
        const int HT_CAPTION = 0x2;

        private void move_window(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        //END --- TO DRAG/MOVE NONE BORDER STYE :)))

        public Form1()
        {
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(move_window); //TO DRAG/MOVE NONE BORDER STYE :)))
            InitializeComponent();
        }

        private void Form1_Load(object sender, System.EventArgs e)
        {

        }

        private void btnDisplaymsg_Click(object sender, System.EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
            this.Hide();
        }

        private void btnCalculator_Click(object sender, System.EventArgs e)
        {
            Calculator c = new Calculator();
            c.Show();
            this.Hide();
        }

        private void btnNextf1_Click(object sender, System.EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();
        }

        private void btnClosef1_Click(object sender, System.EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
