﻿namespace Caraan_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnCalculator = new System.Windows.Forms.Button();
            this.btnNextf1 = new System.Windows.Forms.Button();
            this.btnDisplaymsg = new System.Windows.Forms.Button();
            this.btnClosef1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Kozuka Gothic Pr6N H", 15F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(114, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(221, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "DISPLAYING MESSAGE";
            // 
            // btnCalculator
            // 
            this.btnCalculator.Font = new System.Drawing.Font("Kozuka Gothic Pr6N H", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculator.Location = new System.Drawing.Point(85, 125);
            this.btnCalculator.Name = "btnCalculator";
            this.btnCalculator.Size = new System.Drawing.Size(280, 35);
            this.btnCalculator.TabIndex = 1;
            this.btnCalculator.Text = "Calculator";
            this.btnCalculator.UseVisualStyleBackColor = true;
            this.btnCalculator.Click += new System.EventHandler(this.btnCalculator_Click);
            // 
            // btnNextf1
            // 
            this.btnNextf1.Font = new System.Drawing.Font("Kozuka Gothic Pr6N H", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextf1.Location = new System.Drawing.Point(85, 172);
            this.btnNextf1.Name = "btnNextf1";
            this.btnNextf1.Size = new System.Drawing.Size(280, 35);
            this.btnNextf1.TabIndex = 2;
            this.btnNextf1.Text = "Next Form";
            this.btnNextf1.UseVisualStyleBackColor = true;
            this.btnNextf1.Click += new System.EventHandler(this.btnNextf1_Click);
            // 
            // btnDisplaymsg
            // 
            this.btnDisplaymsg.Font = new System.Drawing.Font("Kozuka Gothic Pr6N H", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplaymsg.Location = new System.Drawing.Point(85, 79);
            this.btnDisplaymsg.Name = "btnDisplaymsg";
            this.btnDisplaymsg.Size = new System.Drawing.Size(280, 35);
            this.btnDisplaymsg.TabIndex = 0;
            this.btnDisplaymsg.Text = "Display Message";
            this.btnDisplaymsg.UseVisualStyleBackColor = true;
            this.btnDisplaymsg.Click += new System.EventHandler(this.btnDisplaymsg_Click);
            // 
            // btnClosef1
            // 
            this.btnClosef1.Font = new System.Drawing.Font("Kozuka Gothic Pr6N H", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClosef1.Location = new System.Drawing.Point(85, 246);
            this.btnClosef1.Name = "btnClosef1";
            this.btnClosef1.Size = new System.Drawing.Size(280, 35);
            this.btnClosef1.TabIndex = 3;
            this.btnClosef1.Text = "Close";
            this.btnClosef1.UseVisualStyleBackColor = true;
            this.btnClosef1.Click += new System.EventHandler(this.btnClosef1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Lavender;
            this.panel1.Location = new System.Drawing.Point(3, 42);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(444, 270);
            this.panel1.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(451, 315);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnClosef1);
            this.Controls.Add(this.btnNextf1);
            this.Controls.Add(this.btnDisplaymsg);
            this.Controls.Add(this.btnCalculator);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCalculator;
        private System.Windows.Forms.Button btnNextf1;
        private System.Windows.Forms.Button btnDisplaymsg;
        private System.Windows.Forms.Button btnClosef1;
        private System.Windows.Forms.Panel panel1;
    }
}