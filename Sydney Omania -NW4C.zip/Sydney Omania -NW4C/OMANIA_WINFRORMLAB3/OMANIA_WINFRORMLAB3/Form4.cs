﻿

namespace OMANIA_WINFRORMLAB3
{
    public partial class Form4 : System.Windows.Forms.Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show("Hello " + textBox1.Text + "!", "Message");
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }

        private void button3_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
