﻿

namespace OMANIA_WINFRORMLAB3
{
    public partial class Calculator : System.Windows.Forms.Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, System.EventArgs e)
        {

        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            txtNumber.Text = txtNumber.Text + button1.Text;
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            txtNumber.Text = txtNumber.Text + button2.Text;
        }

        private void button3_Click(object sender, System.EventArgs e)
        {
            txtNumber.Text = txtNumber.Text + button3.Text;
        }

        private void button5_Click(object sender, System.EventArgs e)
        {
            txtNumber.Text = txtNumber.Text + button5.Text;
        }

        private void button6_Click(object sender, System.EventArgs e)
        {
            txtNumber.Text = txtNumber.Text + button6.Text;
        }

        private void button7_Click(object sender, System.EventArgs e)
        {
            txtNumber.Text = txtNumber.Text + button7.Text;
        }

        private void button9_Click(object sender, System.EventArgs e)
        {
            txtNumber.Text = txtNumber.Text + button9.Text;
        }

        private void button10_Click(object sender, System.EventArgs e)
        {
            txtNumber.Text = txtNumber.Text + button10.Text;
        }

        private void button11_Click(object sender, System.EventArgs e)
        {
            txtNumber.Text = txtNumber.Text + button11.Text;
        }

        private void button13_Click(object sender, System.EventArgs e)
        {
            txtNumber.Text = txtNumber.Text + button13.Text;
        }

        private void button14_Click(object sender, System.EventArgs e)
        {
            txtNumber.Text = txtNumber.Text + button14.Text;
        }

        private void button15_Click(object sender, System.EventArgs e)
        {
            txtNumber.Text = "";
        }

        private void buttonClose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void buttonSum_Click(object sender, System.EventArgs e)
        {
            DeclareVariable.total1 = DeclareVariable.total1 + double.Parse(txtNumber.Text);
            txtNumber.Clear();

            DeclareVariable.btnsum = true;
            DeclareVariable.btndiff = false;
            DeclareVariable.btnprod = false;
            DeclareVariable.btnqoutient = false;
        }

        private void buttonDiff_Click(object sender, System.EventArgs e)
        {
            DeclareVariable.total1 = DeclareVariable.total1 + double.Parse(txtNumber.Text);
            txtNumber.Clear();

            DeclareVariable.btnsum = false;
            DeclareVariable.btndiff = true;
            DeclareVariable.btnprod = false;
            DeclareVariable.btnqoutient = false;
        }

        private void buttonProd_Click(object sender, System.EventArgs e)
        {
            DeclareVariable.total1 = DeclareVariable.total1 + double.Parse(txtNumber.Text);
            txtNumber.Clear();

            DeclareVariable.btnsum = false;
            DeclareVariable.btndiff = false;
            DeclareVariable.btnprod = true;
            DeclareVariable.btnqoutient = false;
        }

        private void buttonQoutient_Click(object sender, System.EventArgs e)
        {
            DeclareVariable.total1 = DeclareVariable.total1 + double.Parse(txtNumber.Text);
            txtNumber.Clear();

            DeclareVariable.btnsum = false;
            DeclareVariable.btndiff = false;
            DeclareVariable.btnprod = false;
            DeclareVariable.btnqoutient = true;
        }

        private void buttonEquals_Click(object sender, System.EventArgs e)
        {
            if (DeclareVariable.btnsum == true)
            {
                DeclareVariable.total2 = DeclareVariable.total1 + double.Parse(txtNumber.Text);

            }

            else if (DeclareVariable.btndiff == true)
            {

                DeclareVariable.total2 = DeclareVariable.total1 - double.Parse(txtNumber.Text);

            }

            else if (DeclareVariable.btnprod == true)
            {
                DeclareVariable.total2 = DeclareVariable.total1 * double.Parse(txtNumber.Text);
            }
            else if (DeclareVariable.btnqoutient == true)
            {
                DeclareVariable.total2 = DeclareVariable.total1 / double.Parse(txtNumber.Text);
            }

            txtNumber.Text = DeclareVariable.total2.ToString();
            DeclareVariable.total1 = 0;
        }
    }
}