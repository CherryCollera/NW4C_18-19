﻿

namespace OMANIA_WINFRORMLAB3
{
    public partial class Form3 : System.Windows.Forms.Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnInteger_Click(object sender, System.EventArgs e)
        {
            DeclareVariable.buttonInt = true;
            DeclareVariable.buttonDouble = false;
            DeclareVariable.buttonFloat = false;
        }

        private void textBox2_TextChanged(object sender, System.EventArgs e)
        {

        }

        private void btnDouble_Click(object sender, System.EventArgs e)
        {
            DeclareVariable.buttonInt = false;
            DeclareVariable.buttonDouble = true;
            DeclareVariable.buttonFloat = false;
        }

        private void btnFloat_Click(object sender, System.EventArgs e)
        {
            DeclareVariable.buttonInt = false;
            DeclareVariable.buttonDouble = false;
            DeclareVariable.buttonFloat = true;
        }

        private void btnSum_Click(object sender, System.EventArgs e)
        {
            if (num1.Text == "" && num2.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Please Input Some Value in the TextBox");
            }
            else
            {
                if (DeclareVariable.buttonInt == true)
                {
                    try
                    {
                        DeclareVariable.total = System.Convert.ToInt32(num1.Text) + System.Convert.ToInt32(num2.Text);
                       num1.Clear();
                        num2.Clear();
                        System.Windows.Forms.MessageBox.Show("Answer: " + DeclareVariable.total);
                    }
                    catch (System.FormatException)
                    {
                       num1.Clear();
                       num2.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!");
                    }
                }
                else if (DeclareVariable.buttonDouble == true)
                {
                    try
                    {
                        DeclareVariable.total = System.Convert.ToDouble(num1.Text) + System.Convert.ToDouble(num2.Text);
                        num1.Clear();
                        num2.Clear();
                        System.Windows.Forms.MessageBox.Show("Answer: " + DeclareVariable.total);
                    }
                    catch (System.FormatException)
                    {
                        num1.Clear();
                        num2.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!");
                    }
                }
                else if (DeclareVariable.buttonFloat == true)
                {
                    try
                    {
                        DeclareVariable.total = float.Parse(num1.Text, System.Globalization.CultureInfo.InvariantCulture.NumberFormat) + float.Parse(num2.Text, System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                       num1.Clear();
                        num2.Clear();
                        System.Windows.Forms.MessageBox.Show("Answer: " + DeclareVariable.total);
                    }
                    catch (System.FormatException)
                    {
                        num1.Clear();
                       num2.Clear();
                        System.Windows.Forms.MessageBox.Show("The format is incorrect!");
                    }
                }
            }
        }

        private void button6_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.ShowDialog();
        }

        private void button5_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form4 form4 = new Form4();
            form4.ShowDialog();
        }

        private void button7_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}

