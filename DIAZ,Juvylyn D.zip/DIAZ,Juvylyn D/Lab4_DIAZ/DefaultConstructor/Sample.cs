﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefaultConstructor
{
    class Sample
    {

        public string firstname, lastname;
        public Sample()
        {
            firstname = "Juvylyn";
            lastname = "Diaz";


        }
    }
}
