﻿

namespace DIAZ_WINFORMLAB3
{
    public partial class Calculator : System.Windows.Forms.Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

       
        private void label2_Click(object sender, System.EventArgs e)
        {

        }

        private void txtboxcalcu_TextChanged(object sender, System.EventArgs e)
        {
           
        }

        private void btnsum_Click(object sender, System.EventArgs e)
        {

            DeclareVar.total1 = DeclareVar.total1 + double.Parse (txtboxcalcu.Text);
            txtboxcalcu.Clear();

            DeclareVar.btnsum = true;
            DeclareVar.btndiff = false;
            DeclareVar.btnprod = false;
            DeclareVar.btnqoutient = false;

            
        }

        private void btndiff_Click(object sender, System.EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtboxcalcu.Text);
            txtboxcalcu.Clear();

            DeclareVar.btnsum = false;
            DeclareVar.btndiff = true;
            DeclareVar.btnprod = false;
            DeclareVar.btnqoutient = false;
        
        }

        private void btnprod_Click(object sender, System.EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtboxcalcu.Text);
            txtboxcalcu.Clear();

            DeclareVar.btnsum = false;
            DeclareVar.btndiff = false;
            DeclareVar.btnprod = true;
            DeclareVar.btnqoutient = false;

            
        }

        private void btnqoutient_Click(object sender, System.EventArgs e)
        {
           DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtboxcalcu.Text);
            txtboxcalcu.Clear();

            DeclareVar.btnsum = false;
            DeclareVar.btndiff = false;
            DeclareVar.btnprod = false;
            DeclareVar.btnqoutient = true;
          
        }

        private void btnequal_Click(object sender, System.EventArgs e)
        {
            if (DeclareVar.btnsum == true)
            {
                DeclareVar.total2 = DeclareVar.total1 + double.Parse(txtboxcalcu.Text);
                
            }

            else if (DeclareVar.btndiff == true)
                    {
                
                DeclareVar.total2 = DeclareVar.total1 - double.Parse(txtboxcalcu.Text);

            }

            else if (DeclareVar.btnprod == true)
            {
                DeclareVar.total2 = DeclareVar.total1  * double.Parse(txtboxcalcu.Text);
            }
            else if  (DeclareVar.btnqoutient == true)
            {
                DeclareVar.total2 = DeclareVar.total1 / double.Parse(txtboxcalcu.Text);
            }

            txtboxcalcu.Text = DeclareVar.total2.ToString();
            DeclareVar.total1 = 0;
        }
        private void btn0_Click(object sender, System.EventArgs e)
        {
            txtboxcalcu.Text = txtboxcalcu.Text + btn0;

        }

        private void btn1_Click(object sender, System.EventArgs e)
        {
            txtboxcalcu.Text = txtboxcalcu.Text + btn1.Text;
        }

        

        private void btn2_Click(object sender, System.EventArgs e)
        {
            txtboxcalcu.Text = txtboxcalcu.Text + btn2.Text;
        }

        private void btn3_Click(object sender, System.EventArgs e)
        {
            txtboxcalcu.Text = txtboxcalcu.Text + btn3.Text;
        }

        private void btn4_Click(object sender, System.EventArgs e)
        {
            txtboxcalcu.Text = txtboxcalcu.Text + btn4.Text;
        }

        private void btn5_Click(object sender, System.EventArgs e)
        {
            txtboxcalcu.Text = txtboxcalcu.Text + btn5.Text;
        }

        private void btn6_Click(object sender, System.EventArgs e)
        {
            txtboxcalcu.Text = txtboxcalcu.Text + btn6.Text;
        }

       
        private void btn7_Click(object sender, System.EventArgs e)
        {
            txtboxcalcu.Text = txtboxcalcu.Text + btn7.Text;
        }

        private void btn8_Click(object sender, System.EventArgs e)
        {
            txtboxcalcu.Text = txtboxcalcu.Text + btn8.Text;
        }

        private void btn9_Click(object sender, System.EventArgs e)
        {
            txtboxcalcu.Text = txtboxcalcu.Text + btn9.Text;
        }
        private void btndot_Click(object sender, System.EventArgs e)
        {
            txtboxcalcu.Text = txtboxcalcu.Text + btndot.Text;
        }
        private void btnclear_Click(object sender, System.EventArgs e)
        {
            txtboxcalcu.Text = "";
        }

       

       

        private void btnclose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
