﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIAZ_WINFORMLAB3
{
    class DeclareVar
    {
        public static double total1 = 0;
        public static double total2 = 0;
        public static bool btnsum = false;
        public static bool btndiff = false;
        public static bool btnprod= false;
        public static bool btnqoutient= false;
        public static bool btnequals = false;

        //bool equals ButtonCliked = false;

        public static double totalsum;
        public static bool IntButton = false;
        public static bool DoubleButton = false;
        public static bool FloatButton = false;

    }
}
