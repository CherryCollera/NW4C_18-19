﻿
namespace DIAZ_WINFORMLAB3
{
    public partial class Form4 : System.Windows.Forms.Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void txtName_TextChanged(object sender, System.EventArgs e)
        {

        }

        private void btnEnter_Click(object sender, System.EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show("Hello!  "  + txtName.Text);
        }

        private void btnClose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }
    }
}
