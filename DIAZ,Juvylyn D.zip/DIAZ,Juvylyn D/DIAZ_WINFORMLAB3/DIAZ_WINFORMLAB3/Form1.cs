﻿

namespace DIAZ_WINFORMLAB3
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show("Hello user!  " );
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }

        private void button3_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Calculator calcu = new Calculator();
            calcu.ShowDialog();
        }

        private void button4_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}