﻿

namespace DIAZ_WINFORMLAB3
{
    public partial class Form3 : System.Windows.Forms.Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        

      
        private void btnInteger_Click(object sender, System.EventArgs e)
        {
            DeclareVar.IntButton = true;
            DeclareVar.DoubleButton = false;
            DeclareVar.FloatButton = false;
        }

        private void buttonDouble_Click(object sender, System.EventArgs e)
        {
            DeclareVar.IntButton = false;
            DeclareVar.DoubleButton = true;
            DeclareVar.FloatButton = false;

        }

        private void buttonFloat_Click(object sender, System.EventArgs e)
        {

            DeclareVar.IntButton = false;
            DeclareVar.DoubleButton = false;
            DeclareVar.FloatButton = true;

        }

        private void button7_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form4 form4 = new Form4();
            form4.ShowDialog();
        }

        private void button8_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.ShowDialog();
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            this.Close();

        }

        private void btnAdd_Click(object sender, System.EventArgs e)
        {
            if (txt1.Text == "" && txt2.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Input numbers in textbox!", "Error");
            }
            else
            {
                if (DeclareVar.IntButton == true)
                {
                    try
                    {
                        DeclareVar.totalsum = System.Convert.ToInt32(txt1.Text) + System.Convert.ToInt32(txt2.Text);
                        txt1.Clear();
                        txt2.Clear();
                        System.Windows.Forms.MessageBox.Show("Intger: " + DeclareVar.totalsum);
                    }
                    catch (System.FormatException)
                    {
                        txt1.Clear();
                        txt2.Clear();
                        System.Windows.Forms.MessageBox.Show("Users invalid input!", "Error");
                    }
                }
                else if (DeclareVar.DoubleButton == true)
                {
                    try
                    {
                        DeclareVar.totalsum = System.Convert.ToDouble(txt1.Text) + System.Convert.ToDouble(txt2.Text);
                        txt1.Clear();
                        txt2.Clear();
                        System.Windows.Forms.MessageBox.Show("Double: " + DeclareVar.totalsum);
                    }
                    catch (System.FormatException)
                    {
                        txt1.Clear();
                        txt2.Clear();
                        System.Windows.Forms.MessageBox.Show("Users invalid input!", "Error");
                    }
                }
                else if (DeclareVar.FloatButton == true)
                {
                    try
                    {
                        DeclareVar.totalsum = float.Parse(txt1.Text, System.Globalization.CultureInfo.InvariantCulture.NumberFormat) + float.Parse(txt2.Text, System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                        txt1.Clear();
                        txt2.Clear();
                        System.Windows.Forms.MessageBox.Show("Float: " + DeclareVar.totalsum);
                    }
                    catch (System.FormatException)
                    {
                        txt1.Clear();
                        txt2.Clear();
                        System.Windows.Forms.MessageBox.Show("Users Invalid input!", "Error");
                    }
                }
            }
        }

        private void txt1_TextChanged(object sender, System.EventArgs e)
        {

        }

        private void label6_Click(object sender, System.EventArgs e)
        {

        }
    }
}



