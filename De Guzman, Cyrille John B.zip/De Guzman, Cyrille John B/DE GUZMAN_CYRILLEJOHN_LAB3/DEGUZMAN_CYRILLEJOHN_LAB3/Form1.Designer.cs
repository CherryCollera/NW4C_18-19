﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNextForm = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnCalculator = new System.Windows.Forms.Button();
            this.btnDisplaying = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnNextForm
            // 
            this.btnNextForm.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnNextForm.Font = new System.Drawing.Font("Rockwell Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextForm.Location = new System.Drawing.Point(24, 197);
            this.btnNextForm.Margin = new System.Windows.Forms.Padding(4);
            this.btnNextForm.Name = "btnNextForm";
            this.btnNextForm.Size = new System.Drawing.Size(184, 64);
            this.btnNextForm.TabIndex = 15;
            this.btnNextForm.Text = "NEXT FORM";
            this.btnNextForm.UseVisualStyleBackColor = false;
            this.btnNextForm.Click += new System.EventHandler(this.btnNextForm_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnClose.Font = new System.Drawing.Font("Rockwell Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(229, 197);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(191, 64);
            this.btnClose.TabIndex = 14;
            this.btnClose.Text = "CLOSE";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnCalculator
            // 
            this.btnCalculator.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnCalculator.Font = new System.Drawing.Font("Rockwell Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculator.Location = new System.Drawing.Point(229, 112);
            this.btnCalculator.Margin = new System.Windows.Forms.Padding(4);
            this.btnCalculator.Name = "btnCalculator";
            this.btnCalculator.Size = new System.Drawing.Size(191, 64);
            this.btnCalculator.TabIndex = 13;
            this.btnCalculator.Text = "CALCULATOR";
            this.btnCalculator.UseVisualStyleBackColor = false;
            this.btnCalculator.Click += new System.EventHandler(this.btnCalculator_Click);
            // 
            // btnDisplaying
            // 
            this.btnDisplaying.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDisplaying.Cursor = System.Windows.Forms.Cursors.Cross;
            this.btnDisplaying.Font = new System.Drawing.Font("Rockwell Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplaying.Location = new System.Drawing.Point(24, 112);
            this.btnDisplaying.Margin = new System.Windows.Forms.Padding(4);
            this.btnDisplaying.Name = "btnDisplaying";
            this.btnDisplaying.Size = new System.Drawing.Size(184, 64);
            this.btnDisplaying.TabIndex = 12;
            this.btnDisplaying.Text = "DISPLAYING MESSAGE";
            this.btnDisplaying.UseVisualStyleBackColor = false;
            this.btnDisplaying.Click += new System.EventHandler(this.btnDisplaying_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Rockwell", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(52, 53);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(320, 38);
            this.label1.TabIndex = 11;
            this.label1.Text = "Displaying Message";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(448, 363);
            this.Controls.Add(this.btnNextForm);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCalculator);
            this.Controls.Add(this.btnDisplaying);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNextForm;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnCalculator;
        private System.Windows.Forms.Button btnDisplaying;
        private System.Windows.Forms.Label label1;
    }
}