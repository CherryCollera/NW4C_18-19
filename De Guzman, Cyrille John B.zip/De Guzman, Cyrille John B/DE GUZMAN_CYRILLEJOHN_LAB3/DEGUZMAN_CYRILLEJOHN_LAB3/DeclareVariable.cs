﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Calculator
{
    class DeclareVariable
    {

        public static double total1 = 0;
        public static double total2 = 0;

        public static bool plusButtonClicked = false;
        public static bool minusButtonClicked = false;
        public static bool divideButtonClicked = false;
        public static bool multiplyButtonClicked = false;
        public static bool equalButtonCLicked = false;

        public static double total;
        public static bool IntButtonClicked = false;
        public static bool DoubleButtonClicked = false;
        public static bool FloatButtonClicked = false;
    }
}
