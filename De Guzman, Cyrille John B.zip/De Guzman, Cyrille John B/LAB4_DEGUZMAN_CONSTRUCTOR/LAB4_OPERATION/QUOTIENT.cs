﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_OPERATION
{
    class QUOTIENT
    {
        public QUOTIENT()
        {
            try
            {
                DECLARE declare = new DECLARE();
                Console.WriteLine(declare);
                DECLARE.answer = DECLARE.firstnumber / DECLARE.secondnumber;
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine("Error: " + e.Message);
                throw;
            }
        }

    }
}
