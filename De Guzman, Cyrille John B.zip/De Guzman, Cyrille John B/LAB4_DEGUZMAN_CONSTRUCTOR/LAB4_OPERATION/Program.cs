﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_OPERATION
{
    class Program
    {
        static void Main(string[] args)
        {
            QUOTIENT q = new QUOTIENT();
            Console.WriteLine("\nThe quotient is: " + DECLARE.answer);
            Console.ReadLine();

        }
    }
}
