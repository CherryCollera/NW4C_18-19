﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_OPERATION
{
    class DECLARE
    {
        public static int firstnumber, secondnumber, answer;

        static DECLARE()
        {
            try
            {
                Console.WriteLine("Enter two numbers for dividing :)\n");
                Console.Write("Enter first number:\t");
                firstnumber = Convert.ToInt16(Console.ReadLine());
                Console.Write("Enter second number:\t");
                secondnumber = Convert.ToInt16(Console.ReadLine());
            }
            catch (FormatException fe)
            {
                Console.WriteLine("Error: " + fe.Message);
                throw;
            }
        }
    }
}
