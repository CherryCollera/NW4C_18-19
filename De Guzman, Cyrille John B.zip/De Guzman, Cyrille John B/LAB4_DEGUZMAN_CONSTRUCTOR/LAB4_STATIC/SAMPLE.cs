﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_STATIC
{
    class SAMPLE
    {
        public string fname, lname;
        static SAMPLE()
        {
            System.Console.WriteLine("Static Constructor");
        }
        public SAMPLE()
        {
            fname = "Cyrille John";
            lname = "De Guzman";
        }
    }
}
