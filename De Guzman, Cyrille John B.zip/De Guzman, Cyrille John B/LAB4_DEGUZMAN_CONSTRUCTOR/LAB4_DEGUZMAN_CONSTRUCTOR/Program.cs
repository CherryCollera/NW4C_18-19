﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_DEGUZMAN_CONSTRUCTOR
{
    class Program
    {
        static void Main(string[] args)
        {
            SAMPLE name = new SAMPLE();
            Console.WriteLine(name.fname);
            Console.WriteLine(name.lname);
            Console.ReadLine();

        }
    }
}
