﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_PRIVATE
{
    class SAMPLE
    {
        public string fname, lname;
        public SAMPLE(string g, string h)
        {
            fname = g;
            lname = h;
        }
        private SAMPLE()
        {
            System.Console.WriteLine("Private Constructor with no parameters");
        }
    }
}
