﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_PRIVATE
{
    class Program
    {
        static void Main(string[] args)
        {
            SAMPLE name = new SAMPLE("Cyrille John", "De Guzman");
            Console.WriteLine(name.fname + " " + name.lname);
            Console.ReadLine();
        }
    }
}
