﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_PARAMETERIZED
{
    class Program
    {
        static void Main(string[] args)
        {
            SAMPLE name = new SAMPLE("Cyrille John", "De Guzman");
            Console.WriteLine(name.fname);
            Console.WriteLine(name.lname);
            Console.ReadLine();
        }
    }
}
