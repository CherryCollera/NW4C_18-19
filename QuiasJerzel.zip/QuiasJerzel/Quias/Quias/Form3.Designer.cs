﻿namespace Quias
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl2ndName = new System.Windows.Forms.Label();
            this.txtSecond = new System.Windows.Forms.TextBox();
            this.lbl1stName = new System.Windows.Forms.Label();
            this.txtFirst = new System.Windows.Forms.TextBox();
            this.btnCloseForm = new System.Windows.Forms.Button();
            this.btnComputeSum = new System.Windows.Forms.Button();
            this.btnNxtForm = new System.Windows.Forms.Button();
            this.btnFloat = new System.Windows.Forms.Button();
            this.btnDouble = new System.Windows.Forms.Button();
            this.btnInteger = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl2ndName
            // 
            this.lbl2ndName.AutoSize = true;
            this.lbl2ndName.Location = new System.Drawing.Point(351, 118);
            this.lbl2ndName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl2ndName.Name = "lbl2ndName";
            this.lbl2ndName.Size = new System.Drawing.Size(184, 17);
            this.lbl2ndName.TabIndex = 21;
            this.lbl2ndName.Text = "ENTER SECOND NUMBER:";
            // 
            // txtSecond
            // 
            this.txtSecond.Location = new System.Drawing.Point(541, 114);
            this.txtSecond.Margin = new System.Windows.Forms.Padding(4);
            this.txtSecond.Name = "txtSecond";
            this.txtSecond.Size = new System.Drawing.Size(132, 22);
            this.txtSecond.TabIndex = 20;
            // 
            // lbl1stName
            // 
            this.lbl1stName.AutoSize = true;
            this.lbl1stName.Location = new System.Drawing.Point(19, 118);
            this.lbl1stName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl1stName.Name = "lbl1stName";
            this.lbl1stName.Size = new System.Drawing.Size(165, 17);
            this.lbl1stName.TabIndex = 19;
            this.lbl1stName.Text = "ENTER FIRST NUMBER:";
            // 
            // txtFirst
            // 
            this.txtFirst.Location = new System.Drawing.Point(190, 114);
            this.txtFirst.Margin = new System.Windows.Forms.Padding(4);
            this.txtFirst.Name = "txtFirst";
            this.txtFirst.Size = new System.Drawing.Size(132, 22);
            this.txtFirst.TabIndex = 18;
            // 
            // btnCloseForm
            // 
            this.btnCloseForm.Location = new System.Drawing.Point(271, 276);
            this.btnCloseForm.Margin = new System.Windows.Forms.Padding(4);
            this.btnCloseForm.Name = "btnCloseForm";
            this.btnCloseForm.Size = new System.Drawing.Size(137, 28);
            this.btnCloseForm.TabIndex = 17;
            this.btnCloseForm.Text = "CLOSE FORM";
            this.btnCloseForm.UseVisualStyleBackColor = true;
            this.btnCloseForm.Click += new System.EventHandler(this.btnCloseForm_Click);
            // 
            // btnComputeSum
            // 
            this.btnComputeSum.Location = new System.Drawing.Point(271, 166);
            this.btnComputeSum.Margin = new System.Windows.Forms.Padding(4);
            this.btnComputeSum.Name = "btnComputeSum";
            this.btnComputeSum.Size = new System.Drawing.Size(137, 28);
            this.btnComputeSum.TabIndex = 16;
            this.btnComputeSum.Text = "COMPUTE SUM";
            this.btnComputeSum.UseVisualStyleBackColor = true;
            this.btnComputeSum.Click += new System.EventHandler(this.btnComputeSum_Click);
            // 
            // btnNxtForm
            // 
            this.btnNxtForm.Location = new System.Drawing.Point(271, 220);
            this.btnNxtForm.Margin = new System.Windows.Forms.Padding(4);
            this.btnNxtForm.Name = "btnNxtForm";
            this.btnNxtForm.Size = new System.Drawing.Size(137, 28);
            this.btnNxtForm.TabIndex = 15;
            this.btnNxtForm.Text = "NEXT FORM";
            this.btnNxtForm.UseVisualStyleBackColor = true;
            this.btnNxtForm.Click += new System.EventHandler(this.btnNxtForm_Click);
            // 
            // btnFloat
            // 
            this.btnFloat.Location = new System.Drawing.Point(461, 50);
            this.btnFloat.Margin = new System.Windows.Forms.Padding(4);
            this.btnFloat.Name = "btnFloat";
            this.btnFloat.Size = new System.Drawing.Size(100, 28);
            this.btnFloat.TabIndex = 14;
            this.btnFloat.Text = "FLOAT";
            this.btnFloat.UseVisualStyleBackColor = true;
            this.btnFloat.Click += new System.EventHandler(this.btnFloat_Click_1);
            // 
            // btnDouble
            // 
            this.btnDouble.Location = new System.Drawing.Point(271, 50);
            this.btnDouble.Margin = new System.Windows.Forms.Padding(4);
            this.btnDouble.Name = "btnDouble";
            this.btnDouble.Size = new System.Drawing.Size(100, 28);
            this.btnDouble.TabIndex = 13;
            this.btnDouble.Text = "DOUBLE";
            this.btnDouble.UseVisualStyleBackColor = true;
            this.btnDouble.Click += new System.EventHandler(this.btnDouble_Click_1);
            // 
            // btnInteger
            // 
            this.btnInteger.Location = new System.Drawing.Point(72, 50);
            this.btnInteger.Margin = new System.Windows.Forms.Padding(4);
            this.btnInteger.Name = "btnInteger";
            this.btnInteger.Size = new System.Drawing.Size(100, 28);
            this.btnInteger.TabIndex = 12;
            this.btnInteger.Text = "INTEGER";
            this.btnInteger.UseVisualStyleBackColor = true;
            this.btnInteger.Click += new System.EventHandler(this.btnInteger_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(414, 36);
            this.label1.TabIndex = 11;
            this.label1.Text = "COMPUTER CALCULATOR";
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(271, 327);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(137, 28);
            this.btnBack.TabIndex = 22;
            this.btnBack.Text = "BACK";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click_1);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(747, 411);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lbl2ndName);
            this.Controls.Add(this.txtSecond);
            this.Controls.Add(this.lbl1stName);
            this.Controls.Add(this.txtFirst);
            this.Controls.Add(this.btnCloseForm);
            this.Controls.Add(this.btnComputeSum);
            this.Controls.Add(this.btnNxtForm);
            this.Controls.Add(this.btnFloat);
            this.Controls.Add(this.btnDouble);
            this.Controls.Add(this.btnInteger);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl2ndName;
        private System.Windows.Forms.TextBox txtSecond;
        private System.Windows.Forms.Label lbl1stName;
        private System.Windows.Forms.TextBox txtFirst;
        private System.Windows.Forms.Button btnCloseForm;
        private System.Windows.Forms.Button btnComputeSum;
        private System.Windows.Forms.Button btnNxtForm;
        private System.Windows.Forms.Button btnFloat;
        private System.Windows.Forms.Button btnDouble;
        private System.Windows.Forms.Button btnInteger;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBack;
    }
}