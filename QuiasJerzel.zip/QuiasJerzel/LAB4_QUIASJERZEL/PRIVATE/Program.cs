﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRIVATE
{
    class Program
    {
        static void Main(string[] args)
        {
            NAME name = new NAME("Jerzel", "Quias");
            Console.WriteLine(name.fname + " " + name.lname);
            Console.ReadLine();
        }
    }
}
