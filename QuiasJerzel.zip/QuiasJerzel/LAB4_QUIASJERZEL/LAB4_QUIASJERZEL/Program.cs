﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_QUIASJERZEL
{
    class Program
    {
        static void Main(string[] args)
        {
            Name name = new Name();
            Console.WriteLine(name.fname);
            Console.WriteLine(name.lname);
            Console.ReadLine();
        }
    }
}
