﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_QUIASJERZEL
{
    class Name
    {
        public string fname, lname;
        public Name()
        {
            fname = "Jerzel";
            lname = "Quias";
        }
    }
}
