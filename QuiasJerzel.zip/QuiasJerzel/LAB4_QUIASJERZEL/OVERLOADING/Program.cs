﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OVERLOADING
{
    class Program
    {
        static void Main(string[] args)
        {
            NAME name = new NAME();
            NAME pangalan = new NAME("Jerzel", "Quias");
            Console.WriteLine(name.fname + " " + name.lname);
            Console.WriteLine(pangalan.fname + " " + pangalan.lname);
            Console.ReadLine();

        }
    }
}
