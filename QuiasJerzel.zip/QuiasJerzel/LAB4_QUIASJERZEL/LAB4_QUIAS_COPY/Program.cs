﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_QUIAS_COPY
{
    class Program
    {
        static void Main(string[] args)
        {
            NAME name = new NAME("Jerzel ", "Quias");
            NAME pangalan = new NAME(name);
            Console.WriteLine(name);
            Console.WriteLine("\n" + pangalan.fname + "\n\n" + pangalan.lname);
            Console.ReadLine();
        }
    }
}
