﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STATIC
{
    class NAME
    {
        public string fname, lname;
        static NAME()
        {
            System.Console.WriteLine("Static Constructor");
        }
        public NAME()
        {
            fname = "Jerzel";
            lname = "Quias";
        }
    }
}
