﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARAMETERIZED
{
    class NAME
    {
        public string fname, lname;
        public NAME(string a, string b)
        {
            fname = a;
            lname = b;
        }
    }
}
