﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Trajano
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Mariane";
            lastname = "Trajano";
        }
    }
}
