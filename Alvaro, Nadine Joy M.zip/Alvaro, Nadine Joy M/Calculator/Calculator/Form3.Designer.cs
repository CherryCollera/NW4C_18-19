﻿namespace Calculator
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Integer = new System.Windows.Forms.Button();
            this.Double = new System.Windows.Forms.Button();
            this.Float = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFirst = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSecond = new System.Windows.Forms.TextBox();
            this.ComputeSum = new System.Windows.Forms.Button();
            this.NextForm = new System.Windows.Forms.Button();
            this.CloseForm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(227, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Computer Calculator";
            // 
            // Integer
            // 
            this.Integer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Integer.Location = new System.Drawing.Point(14, 69);
            this.Integer.Name = "Integer";
            this.Integer.Size = new System.Drawing.Size(213, 32);
            this.Integer.TabIndex = 1;
            this.Integer.Text = "Integer";
            this.Integer.UseVisualStyleBackColor = true;
            this.Integer.Click += new System.EventHandler(this.Integer_Click);
            // 
            // Double
            // 
            this.Double.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Double.Location = new System.Drawing.Point(245, 69);
            this.Double.Name = "Double";
            this.Double.Size = new System.Drawing.Size(211, 32);
            this.Double.TabIndex = 2;
            this.Double.Text = "Double";
            this.Double.UseVisualStyleBackColor = true;
            this.Double.Click += new System.EventHandler(this.Double_Click);
            // 
            // Float
            // 
            this.Float.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Float.Location = new System.Drawing.Point(469, 69);
            this.Float.Name = "Float";
            this.Float.Size = new System.Drawing.Size(211, 32);
            this.Float.TabIndex = 3;
            this.Float.Text = "Float";
            this.Float.UseVisualStyleBackColor = true;
            this.Float.Click += new System.EventHandler(this.Float_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Enter first number:";
            // 
            // txtFirst
            // 
            this.txtFirst.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirst.Location = new System.Drawing.Point(158, 130);
            this.txtFirst.Name = "txtFirst";
            this.txtFirst.Size = new System.Drawing.Size(166, 26);
            this.txtFirst.TabIndex = 5;
            this.txtFirst.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(330, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Enter second number:";
            // 
            // txtSecond
            // 
            this.txtSecond.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSecond.Location = new System.Drawing.Point(514, 130);
            this.txtSecond.Name = "txtSecond";
            this.txtSecond.Size = new System.Drawing.Size(166, 26);
            this.txtSecond.TabIndex = 7;
            // 
            // ComputeSum
            // 
            this.ComputeSum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComputeSum.Location = new System.Drawing.Point(179, 177);
            this.ComputeSum.Name = "ComputeSum";
            this.ComputeSum.Size = new System.Drawing.Size(357, 28);
            this.ComputeSum.TabIndex = 8;
            this.ComputeSum.Text = "Compute Sum";
            this.ComputeSum.UseVisualStyleBackColor = true;
            this.ComputeSum.Click += new System.EventHandler(this.ComputeSum_Click);
            // 
            // NextForm
            // 
            this.NextForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NextForm.Location = new System.Drawing.Point(179, 211);
            this.NextForm.Name = "NextForm";
            this.NextForm.Size = new System.Drawing.Size(357, 28);
            this.NextForm.TabIndex = 9;
            this.NextForm.Text = "Next Form";
            this.NextForm.UseVisualStyleBackColor = true;
            this.NextForm.Click += new System.EventHandler(this.NextForm_Click);
            // 
            // CloseForm
            // 
            this.CloseForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CloseForm.Location = new System.Drawing.Point(179, 245);
            this.CloseForm.Name = "CloseForm";
            this.CloseForm.Size = new System.Drawing.Size(357, 28);
            this.CloseForm.TabIndex = 10;
            this.CloseForm.Text = "Close Form";
            this.CloseForm.UseVisualStyleBackColor = true;
            this.CloseForm.Click += new System.EventHandler(this.CloseForm_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 294);
            this.Controls.Add(this.CloseForm);
            this.Controls.Add(this.NextForm);
            this.Controls.Add(this.ComputeSum);
            this.Controls.Add(this.txtSecond);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtFirst);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Float);
            this.Controls.Add(this.Double);
            this.Controls.Add(this.Integer);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Integer;
        private System.Windows.Forms.Button Double;
        private System.Windows.Forms.Button Float;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFirst;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSecond;
        private System.Windows.Forms.Button ComputeSum;
        private System.Windows.Forms.Button NextForm;
        private System.Windows.Forms.Button CloseForm;
    }
}