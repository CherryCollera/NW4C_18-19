﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Calculator
{
    public partial class Calculator : System.Windows.Forms.Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + three.Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text +  six.Text;
        }

        private void Display_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

            
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(Display.Text);
            Display.Clear();

            DeclareVar.divideButtonClicked = false;
            DeclareVar.addButtonClicked = true;
            DeclareVar.minusButtonClicked = false;
            DeclareVar.multiplyButtonClicked = false;
        
        }

        private void button8_Click(object sender, EventArgs e)
        {


            DeclareVar.total1 = DeclareVar.total1 + double.Parse(Display.Text);
            Display.Clear();

            DeclareVar.divideButtonClicked = false;
            DeclareVar.addButtonClicked = false;
            DeclareVar.minusButtonClicked = true;
            DeclareVar.multiplyButtonClicked = false;
          

        }

        private void button12_Click(object sender, EventArgs e)
        {

            DeclareVar.total1 = DeclareVar.total1 + double.Parse(Display.Text);
            Display.Clear();

            DeclareVar.divideButtonClicked = false;
            DeclareVar.addButtonClicked = false;
            DeclareVar.minusButtonClicked = false;
            DeclareVar.multiplyButtonClicked = true;

        }

        private void button16_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(Display.Text);
            Display.Clear();

            DeclareVar.divideButtonClicked = true;
            DeclareVar.addButtonClicked = false;
            DeclareVar.minusButtonClicked = false;
            DeclareVar.multiplyButtonClicked = false;
          

        }

        private void one_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + one.Text;
        }

        private void two_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + two.Text;
        }

        private void four_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + four.Text;
        }

        private void five_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + five.Text;
        }

        private void seven_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + seven.Text;
        }

        private void eight_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + eight.Text;
        }

        private void nine_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + nine.Text;
        }

        private void zero_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + zero.Text;
        }

        private void point_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + point.Text;
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            Display.Clear();

        }

        private void equal_Click(object sender, EventArgs e)
        {
            if (DeclareVar.addButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 + double.Parse(Display.Text);
            }
            else if (DeclareVar.minusButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 - double.Parse(Display.Text);
            }
            else if (DeclareVar.multiplyButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 * double.Parse(Display.Text); 
            }
            else if (DeclareVar.divideButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 / double.Parse(Display.Text);
            }
            Display.Text = DeclareVar.total2.ToString();
            DeclareVar.total1 = 0;

        }

        private void done_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
