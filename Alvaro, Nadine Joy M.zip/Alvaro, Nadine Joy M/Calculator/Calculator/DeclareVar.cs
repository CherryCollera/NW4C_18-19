﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class DeclareVar
    {
        public static string dm = "Hi! This is Windows Forms";
        public static string t = "Display Message";
        public const int i = 14;
        public const double d = 14.56;
        public const float f = 14.56f;
        public static int sum;
        public static double total1 = 0;
        public static double total2 = 0;
        public static bool minusButtonClicked = false;
        public static bool addButtonClicked = false;
        public static bool divideButtonClicked = false;
        public static bool multiplyButtonClicked = false;
        // bool equalButtonClicked = false;
    }
}
