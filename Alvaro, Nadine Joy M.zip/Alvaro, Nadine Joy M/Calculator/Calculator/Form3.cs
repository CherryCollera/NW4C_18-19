﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public partial class Form3 : System.Windows.Forms.Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void NextForm_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
        }

        private void CloseForm_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Integer_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show(Convert.ToString(DeclareVar.i),
                 DeclareVar.t);
            
        }

        private void Double_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show(Convert.ToString(DeclareVar.d),
              DeclareVar.t);
        }

        private void Float_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show(Convert.ToString(DeclareVar.f), DeclareVar.t);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ComputeSum_Click(object sender, EventArgs e)
        {
            DeclareVar.sum = System.Convert.ToInt32(txtFirst.Text) + System.Convert.ToInt32(txtSecond.Text);
            System.Windows.Forms.MessageBox.Show(System.Convert.ToString(DeclareVar.sum), DeclareVar.t);
        }
    }
}
