﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation
{
    class Program
    {
        static void Main(string[] args)
        {
            Difference difference = new Difference();
            Console.WriteLine("The difference is " + DeclareVar.diff);
            Console.ReadLine();


        }
    }
}
