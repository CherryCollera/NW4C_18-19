﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticConstructor
{
    class Sample
    {
        public string firstname, lastname;

        static Sample()
        {
            Console.WriteLine("Static Constructor");
        }
        public Sample()
        {
            firstname = "Nadine Joy";
            lastname = "Alvaro";
        }

    }
}
